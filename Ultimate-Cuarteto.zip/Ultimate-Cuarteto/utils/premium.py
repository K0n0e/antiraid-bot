from datetime import datetime
import logging
from database import is_premium_user, get_db_connection

logger = logging.getLogger(__name__)

class PremiumManager:
    """Manage premium user functionality"""
    
    @staticmethod
    async def check_premium_status(user_id: int) -> dict:
        """Get detailed premium status for a user"""
        try:
            conn = await get_db_connection()
            cursor = await conn.execute(
                "SELECT expires_at, activated_at, key_used FROM premium_users WHERE user_id = ?",
                (user_id,)
            )
            result = await cursor.fetchone()
            await conn.close()
            
            if not result:
                return {
                    "is_premium": False,
                    "expires_at": None,
                    "activated_at": None,
                    "key_used": None,
                    "is_expired": False
                }
            
            expires_at, activated_at, key_used = result
            
            # Check if expired
            is_expired = False
            if expires_at:
                try:
                    expire_date = datetime.fromisoformat(expires_at)
                    is_expired = expire_date <= datetime.now()
                except:
                    is_expired = True
            
            return {
                "is_premium": not is_expired,
                "expires_at": expires_at,
                "activated_at": activated_at,
                "key_used": key_used,
                "is_expired": is_expired
            }
            
        except Exception as e:
            logger.error(f"Error checking premium status: {e}")
            return {
                "is_premium": False,
                "expires_at": None,
                "activated_at": None,
                "key_used": None,
                "is_expired": False
            }
    
    @staticmethod
    async def get_premium_users_count() -> int:
        """Get total count of premium users"""
        try:
            conn = await get_db_connection()
            cursor = await conn.execute(
                "SELECT COUNT(*) FROM premium_users WHERE expires_at IS NULL OR expires_at > ?",
                (datetime.now().isoformat(),)
            )
            result = await cursor.fetchone()
            await conn.close()
            return result[0] if result else 0
        except Exception as e:
            logger.error(f"Error getting premium users count: {e}")
            return 0
    
    @staticmethod
    async def get_expiring_soon(days: int = 7) -> list:
        """Get users whose premium expires within specified days"""
        try:
            from datetime import timedelta
            
            cutoff_date = (datetime.now() + timedelta(days=days)).isoformat()
            
            conn = await get_db_connection()
            cursor = await conn.execute(
                "SELECT user_id, expires_at FROM premium_users WHERE expires_at IS NOT NULL AND expires_at BETWEEN ? AND ?",
                (datetime.now().isoformat(), cutoff_date)
            )
            results = await cursor.fetchall()
            await conn.close()
            
            return [{"user_id": row[0], "expires_at": row[1]} for row in results]
            
        except Exception as e:
            logger.error(f"Error getting expiring premium users: {e}")
            return []

    @staticmethod
    async def cleanup_expired_premium():
        """Remove expired premium users from database"""
        try:
            conn = await get_db_connection()
            cursor = await conn.execute(
                "DELETE FROM premium_users WHERE expires_at IS NOT NULL AND expires_at < ?",
                (datetime.now().isoformat(),)
            )
            deleted_count = cursor.rowcount
            await conn.commit()
            await conn.close()
            
            logger.info(f"Cleaned up {deleted_count} expired premium users")
            return deleted_count
            
        except Exception as e:
            logger.error(f"Error cleaning up expired premium: {e}")
            return 0
