import discord
import logging
from database import (
    is_blacklisted, get_blacklist_reason, add_to_blacklist, 
    remove_from_blacklist, get_db_connection
)

logger = logging.getLogger(__name__)

class BlacklistManager:
    """Manage global blacklist functionality"""
    
    def __init__(self):
        self.cache = {}  # Simple cache for frequently checked users
    
    async def is_blacklisted(self, user_id: int) -> bool:
        """Check if user is blacklisted (with caching)"""
        # Check cache first
        if user_id in self.cache:
            return self.cache[user_id]
        
        # Check database
        result = await is_blacklisted(user_id)
        
        # Cache result for 5 minutes
        self.cache[user_id] = result
        
        return result
    
    async def get_blacklist_reason(self, user_id: int) -> str:
        """Get blacklist reason for user"""
        return await get_blacklist_reason(user_id)
    
    async def add_user_to_blacklist(self, user_id: int, reason: str, added_by: int, is_bot: bool = False):
        """Add user to blacklist and invalidate cache"""
        await add_to_blacklist(user_id, reason, added_by, is_bot)
        
        # Update cache
        self.cache[user_id] = True
        
        logger.info(f"Added user {user_id} to blacklist: {reason}")
    
    async def remove_user_from_blacklist(self, user_id: int):
        """Remove user from blacklist and invalidate cache"""
        await remove_from_blacklist(user_id)
        
        # Update cache
        self.cache[user_id] = False
        
        logger.info(f"Removed user {user_id} from blacklist")
    
    async def enforce_blacklist_in_guild(self, guild: discord.Guild):
        """Enforce blacklist in a specific guild"""
        try:
            banned_count = 0
            
            # Get all blacklisted users
            conn = await get_db_connection()
            cursor = await conn.execute("SELECT user_id, reason FROM global_blacklist")
            blacklisted_users = await cursor.fetchall()
            await conn.close()
            
            for user_id, reason in blacklisted_users:
                try:
                    # Check if user is in guild
                    member = guild.get_member(user_id)
                    if member:
                        await member.ban(reason=f"Global blacklist: {reason}")
                        banned_count += 1
                        logger.info(f"Enforced blacklist ban for {member} in {guild.name}")
                    
                except discord.Forbidden:
                    logger.warning(f"Could not ban blacklisted user {user_id} in {guild.name} - insufficient permissions")
                except discord.NotFound:
                    continue
                except Exception as e:
                    logger.error(f"Error enforcing blacklist for user {user_id}: {e}")
            
            if banned_count > 0:
                logger.info(f"Enforced {banned_count} blacklist bans in {guild.name}")
            
            return banned_count
            
        except Exception as e:
            logger.error(f"Error enforcing blacklist in guild {guild.name}: {e}")
            return 0
    
    async def get_blacklist_stats(self) -> dict:
        """Get blacklist statistics"""
        try:
            conn = await get_db_connection()
            
            # Total blacklisted users
            cursor = await conn.execute("SELECT COUNT(*) FROM global_blacklist WHERE is_bot = FALSE")
            user_count = (await cursor.fetchone())[0]
            
            # Total blacklisted bots
            cursor = await conn.execute("SELECT COUNT(*) FROM global_blacklist WHERE is_bot = TRUE")
            bot_count = (await cursor.fetchone())[0]
            
            # Recent additions (last 24 hours)
            from datetime import datetime, timedelta
            yesterday = (datetime.now() - timedelta(hours=24)).isoformat()
            cursor = await conn.execute(
                "SELECT COUNT(*) FROM global_blacklist WHERE added_at > ?",
                (yesterday,)
            )
            recent_count = (await cursor.fetchone())[0]
            
            await conn.close()
            
            return {
                "total_users": user_count,
                "total_bots": bot_count,
                "total_entries": user_count + bot_count,
                "recent_additions": recent_count
            }
            
        except Exception as e:
            logger.error(f"Error getting blacklist stats: {e}")
            return {
                "total_users": 0,
                "total_bots": 0,
                "total_entries": 0,
                "recent_additions": 0
            }
    
    async def clear_cache(self):
        """Clear the blacklist cache"""
        self.cache.clear()
        logger.info("Blacklist cache cleared")
    
    async def get_blacklisted_users_in_guild(self, guild: discord.Guild) -> list:
        """Get list of blacklisted users currently in the guild"""
        try:
            blacklisted_members = []
            
            # Get all blacklisted user IDs
            conn = await get_db_connection()
            cursor = await conn.execute("SELECT user_id, reason FROM global_blacklist")
            blacklisted_users = await cursor.fetchall()
            await conn.close()
            
            for user_id, reason in blacklisted_users:
                member = guild.get_member(user_id)
                if member:
                    blacklisted_members.append({
                        "member": member,
                        "reason": reason
                    })
            
            return blacklisted_members
            
        except Exception as e:
            logger.error(f"Error getting blacklisted users in guild: {e}")
            return []
