from database import is_premium_user, is_bot_admin
from config import FOUNDER_ID

def is_founder(user_id: int) -> bool:
    """Check if user is the founder"""
    return user_id == FOUNDER_ID

async def check_premium(user_id: int) -> bool:
    """Check if user has premium access"""
    # Founder always has premium
    if is_founder(user_id):
        return True
    
    # Check if user is bot admin (they get premium access)
    if await is_bot_admin(user_id):
        return True
    
    # Check premium status
    return await is_premium_user(user_id)

async def check_admin_permissions(user_id: int) -> bool:
    """Check if user has admin permissions"""
    if is_founder(user_id):
        return True
    
    return await is_bot_admin(user_id)

def check_founder_only(user_id: int) -> bool:
    """Check if user is founder (for founder-only commands)"""
    return is_founder(user_id)
