import discord
from discord.ext import commands, tasks
import asyncio
import logging
import os
from datetime import datetime
import traceback

from database import init_db, get_db_connection
from commands.admin import AdminCommands
from commands.moderation import ModerationCommands
from commands.antiraid import AntiRaidCommands
from commands.profile import ProfileCommands
from commands.help import HelpCommands
from utils.permissions import check_premium, is_founder, check_admin_permissions
from utils.blacklist import BlacklistManager
from config import FOUNDER_ID, FOUNDER_NAME

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class AntiRaidBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        intents.guilds = True
        intents.bans = True
        
        super().__init__(
            command_prefix='!',
            intents=intents,
            help_command=None
        )
        
        self.blacklist_manager = BlacklistManager()
        
    async def setup_hook(self):
        """Initialize database and sync commands"""
        await init_db()
        
        # Add command cogs
        await self.add_cog(AdminCommands(self))
        await self.add_cog(ModerationCommands(self))
        await self.add_cog(AntiRaidCommands(self))
        await self.add_cog(ProfileCommands(self))
        await self.add_cog(HelpCommands(self))
        
        # Start background tasks
        self.cleanup_expired_keys.start()
        self.check_blacklist_enforcement.start()
        
        # Sync slash commands
        try:
            synced = await self.tree.sync()
            logger.info(f"Synced {len(synced)} command(s)")
        except Exception as e:
            logger.error(f"Failed to sync commands: {e}")

    async def on_ready(self):
        logger.info(f'{self.user} has connected to Discord!')
        logger.info(f'Bot is in {len(self.guilds)} guilds')
        
        # Set bot status
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="for raids | Premium Anti-Raid Bot"
            )
        )

    async def on_member_join(self, member):
        """Check if joining member is blacklisted"""
        if await self.blacklist_manager.is_blacklisted(member.id):
            try:
                reason = await self.blacklist_manager.get_blacklist_reason(member.id)
                await member.ban(reason=f"Global blacklist: {reason}")
                logger.info(f"Auto-banned blacklisted user {member} ({member.id}) from {member.guild.name}")
            except discord.Forbidden:
                logger.warning(f"Could not ban blacklisted user {member} in {member.guild.name} - insufficient permissions")
            except Exception as e:
                logger.error(f"Error auto-banning blacklisted user: {e}")

    async def on_guild_join(self, guild):
        """Enforce blacklist when bot joins new guild"""
        logger.info(f"Joined guild: {guild.name} ({guild.id})")
        await self.blacklist_manager.enforce_blacklist_in_guild(guild)
    
    async def on_message(self, message):
        """Handle global announcements from founder"""
        if message.author.id == FOUNDER_ID and not message.author.bot:
            # Check if this is in a configured announcement channel
            if message.channel.name.lower() in ['anuncios-globales', 'global-announcements']:
                await self.send_global_announcement(message)
    
    async def send_global_announcement(self, message):
        """Send message to all configured announcement channels"""
        try:
            conn = await get_db_connection()
            cursor = await conn.execute(
                "SELECT guild_id, announcements_channel FROM guild_settings WHERE announcements_channel IS NOT NULL"
            )
            channels = await cursor.fetchall()
            await conn.close()
            
            embed = discord.Embed(
                title="📢 ANUNCIO GLOBAL - CUARTETO SQUAD",
                description=message.content,
                color=0xffd700,
                timestamp=message.created_at
            )
            embed.set_author(
                name=f"{message.author.display_name} (Fundador)",
                icon_url=message.author.display_avatar.url
            )
            embed.set_footer(text="Anuncio oficial de Cuarteto Squad")
            
            sent_count = 0
            for guild_id, channel_id in channels:
                try:
                    guild = self.get_guild(guild_id)
                    if guild:
                        channel = guild.get_channel(channel_id)
                        if channel:
                            await channel.send(embed=embed)
                            sent_count += 1
                except:
                    continue
                    
            logger.info(f"Global announcement sent to {sent_count} servers")
            
        except Exception as e:
            logger.error(f"Error sending global announcement: {e}")

    async def on_application_command_error(self, interaction, error):
        """Global error handler for slash commands"""
        if isinstance(error, commands.CommandOnCooldown):
            await interaction.response.send_message(
                f"⏰ Command on cooldown. Try again in {error.retry_after:.2f}s",
                ephemeral=True
            )
        elif isinstance(error, commands.MissingPermissions):
            await interaction.response.send_message(
                "❌ You don't have permission to use this command.",
                ephemeral=True
            )
        else:
            logger.error(f"Command error: {error}")
            logger.error(traceback.format_exc())
            
            if not interaction.response.is_done():
                await interaction.response.send_message(
                    "❌ An error occurred while processing your command.",
                    ephemeral=True
                )

    @tasks.loop(hours=1)
    async def cleanup_expired_keys(self):
        """Remove expired premium keys"""
        try:
            conn = await get_db_connection()
            await conn.execute(
                "DELETE FROM premium_keys WHERE expires_at < ? AND expires_at IS NOT NULL",
                (datetime.now().isoformat(),)
            )
            await conn.commit()
            await conn.close()
        except Exception as e:
            logger.error(f"Error cleaning up expired keys: {e}")

    @tasks.loop(minutes=30)
    async def check_blacklist_enforcement(self):
        """Periodically check and enforce blacklist across all guilds"""
        try:
            for guild in self.guilds:
                await self.blacklist_manager.enforce_blacklist_in_guild(guild)
        except Exception as e:
            logger.error(f"Error in blacklist enforcement: {e}")

    @cleanup_expired_keys.before_loop
    @check_blacklist_enforcement.before_loop
    async def before_tasks(self):
        await self.wait_until_ready()

async def main():
    """Main bot startup function"""
    bot_token = os.getenv('DISCORD_TOKEN')
    if not bot_token:
        logger.error("DISCORD_TOKEN environment variable not set!")
        return
    
    bot = AntiRaidBot()
    
    try:
        await bot.start(bot_token)
    except KeyboardInterrupt:
        logger.info("Bot shutdown requested")
    except Exception as e:
        logger.error(f"Bot startup error: {e}")
        logger.error(traceback.format_exc())
    finally:
        await bot.close()

if __name__ == "__main__":
    asyncio.run(main())
