import aiosqlite
import asyncio
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

DATABASE_FILE = "antiraid_bot.db"

async def get_db_connection():
    """Get database connection"""
    return await aiosqlite.connect(DATABASE_FILE)

async def init_db():
    """Initialize database tables"""
    conn = await get_db_connection()
    
    try:
        # Premium keys table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS premium_keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key_code TEXT UNIQUE NOT NULL,
                user_id INTEGER,
                created_at TEXT NOT NULL,
                expires_at TEXT,
                created_by INTEGER NOT NULL,
                is_used BOOLEAN DEFAULT FALSE
            )
        """)
        
        # Premium users table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS premium_users (
                user_id INTEGER PRIMARY KEY,
                expires_at TEXT,
                activated_at TEXT NOT NULL,
                key_used TEXT
            )
        """)
        
        # Bot admins table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS bot_admins (
                user_id INTEGER PRIMARY KEY,
                assigned_by INTEGER NOT NULL,
                assigned_at TEXT NOT NULL
            )
        """)
        
        # Bot staff table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS bot_staff (
                user_id INTEGER PRIMARY KEY,
                assigned_by INTEGER NOT NULL,
                assigned_at TEXT NOT NULL
            )
        """)
        
        # Global blacklist table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS global_blacklist (
                user_id INTEGER PRIMARY KEY,
                reason TEXT NOT NULL,
                added_by INTEGER NOT NULL,
                added_at TEXT NOT NULL,
                is_bot BOOLEAN DEFAULT FALSE
            )
        """)
        
        # User profiles table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS user_profiles (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                join_date TEXT NOT NULL,
                commands_used INTEGER DEFAULT 0,
                last_seen TEXT
            )
        """)
        
        # Guild settings table (expanded)
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS guild_settings (
                guild_id INTEGER PRIMARY KEY,
                antiraid_enabled BOOLEAN DEFAULT TRUE,
                auto_mod_enabled BOOLEAN DEFAULT TRUE,
                raid_detection_threshold INTEGER DEFAULT 5,
                raid_mode_enabled BOOLEAN DEFAULT FALSE,
                raid_mode_level INTEGER DEFAULT 1,
                min_account_age_days INTEGER DEFAULT 0,
                auto_dehoist_enabled BOOLEAN DEFAULT FALSE,
                anti_invite_enabled BOOLEAN DEFAULT FALSE,
                anti_invite_action TEXT DEFAULT 'delete',
                anti_spam_enabled BOOLEAN DEFAULT FALSE,
                anti_spam_limit INTEGER DEFAULT 10,
                anti_spam_action TEXT DEFAULT 'timeout',
                join_logs_enabled BOOLEAN DEFAULT FALSE,
                join_logs_channel INTEGER,
                auto_role_enabled BOOLEAN DEFAULT FALSE,
                auto_role_id INTEGER,
                captcha_enabled BOOLEAN DEFAULT FALSE,
                captcha_channel INTEGER,
                announcements_channel INTEGER,
                emergency_lock BOOLEAN DEFAULT FALSE,
                emergency_lock_by INTEGER,
                emergency_lock_at TEXT,
                emergency_unlock_by INTEGER,
                emergency_unlock_at TEXT,
                created_at TEXT NOT NULL
            )
        """)
        
        # Server whitelist table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS server_whitelist (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                reason TEXT NOT NULL,
                added_by INTEGER NOT NULL,
                added_at TEXT NOT NULL,
                UNIQUE(guild_id, user_id)
            )
        """)
        
        # Channel backups table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS channel_backups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                backup_data TEXT NOT NULL,
                created_by INTEGER NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        
        # Server backups table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS server_backups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                backup_data TEXT NOT NULL,
                created_by INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                includes_messages BOOLEAN DEFAULT FALSE
            )
        """)
        
        # Warnings table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS user_warnings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                warned_by INTEGER NOT NULL,
                reason TEXT NOT NULL,
                warned_at TEXT NOT NULL
            )
        """)
        
        # Anti-spam tracking table
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS spam_tracking (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                message_count INTEGER DEFAULT 1,
                last_message_at TEXT NOT NULL,
                UNIQUE(guild_id, user_id)
            )
        """)
        
        await conn.commit()
        logger.info("Database initialized successfully")
        
    except Exception as e:
        logger.error(f"Error initializing database: {e}")
        raise
    finally:
        await conn.close()

async def create_premium_key(key_code: str, expires_at: str = None, created_by: int = None):
    """Create a new premium key"""
    conn = await get_db_connection()
    try:
        await conn.execute(
            "INSERT INTO premium_keys (key_code, created_at, expires_at, created_by) VALUES (?, ?, ?, ?)",
            (key_code, datetime.now().isoformat(), expires_at, created_by)
        )
        await conn.commit()
    finally:
        await conn.close()

async def use_premium_key(key_code: str, user_id: int):
    """Use a premium key for a user"""
    conn = await get_db_connection()
    try:
        # Check if key exists and is unused
        cursor = await conn.execute(
            "SELECT expires_at FROM premium_keys WHERE key_code = ? AND is_used = FALSE",
            (key_code,)
        )
        result = await cursor.fetchone()
        
        if not result:
            return False
        
        expires_at = result[0]
        
        # Mark key as used
        await conn.execute(
            "UPDATE premium_keys SET is_used = TRUE, user_id = ? WHERE key_code = ?",
            (user_id, key_code)
        )
        
        # Add/update premium user
        await conn.execute(
            "INSERT OR REPLACE INTO premium_users (user_id, expires_at, activated_at, key_used) VALUES (?, ?, ?, ?)",
            (user_id, expires_at, datetime.now().isoformat(), key_code)
        )
        
        await conn.commit()
        return True
        
    finally:
        await conn.close()

async def is_premium_user(user_id: int):
    """Check if user has premium access"""
    conn = await get_db_connection()
    try:
        cursor = await conn.execute(
            "SELECT expires_at FROM premium_users WHERE user_id = ?",
            (user_id,)
        )
        result = await cursor.fetchone()
        
        if not result:
            return False
        
        expires_at = result[0]
        if expires_at is None:  # Lifetime premium
            return True
        
        return datetime.fromisoformat(expires_at) > datetime.now()
        
    finally:
        await conn.close()

async def add_bot_admin(user_id: int, assigned_by: int):
    """Add a bot admin"""
    conn = await get_db_connection()
    try:
        await conn.execute(
            "INSERT OR REPLACE INTO bot_admins (user_id, assigned_by, assigned_at) VALUES (?, ?, ?)",
            (user_id, assigned_by, datetime.now().isoformat())
        )
        await conn.commit()
    finally:
        await conn.close()

async def is_bot_admin(user_id: int):
    """Check if user is bot admin"""
    conn = await get_db_connection()
    try:
        cursor = await conn.execute(
            "SELECT user_id FROM bot_admins WHERE user_id = ?",
            (user_id,)
        )
        result = await cursor.fetchone()
        return result is not None
    finally:
        await conn.close()

async def add_to_blacklist(user_id: int, reason: str, added_by: int, is_bot: bool = False):
    """Add user to global blacklist"""
    conn = await get_db_connection()
    try:
        await conn.execute(
            "INSERT OR REPLACE INTO global_blacklist (user_id, reason, added_by, added_at, is_bot) VALUES (?, ?, ?, ?, ?)",
            (user_id, reason, added_by, datetime.now().isoformat(), is_bot)
        )
        await conn.commit()
    finally:
        await conn.close()

async def remove_from_blacklist(user_id: int):
    """Remove user from global blacklist"""
    conn = await get_db_connection()
    try:
        await conn.execute(
            "DELETE FROM global_blacklist WHERE user_id = ?",
            (user_id,)
        )
        await conn.commit()
    finally:
        await conn.close()

async def is_blacklisted(user_id: int):
    """Check if user is blacklisted"""
    conn = await get_db_connection()
    try:
        cursor = await conn.execute(
            "SELECT reason FROM global_blacklist WHERE user_id = ?",
            (user_id,)
        )
        result = await cursor.fetchone()
        return result is not None
    finally:
        await conn.close()

async def get_blacklist_reason(user_id: int):
    """Get blacklist reason for user"""
    conn = await get_db_connection()
    try:
        cursor = await conn.execute(
            "SELECT reason FROM global_blacklist WHERE user_id = ?",
            (user_id,)
        )
        result = await cursor.fetchone()
        return result[0] if result else None
    finally:
        await conn.close()

async def update_user_profile(user_id: int, username: str):
    """Update user profile"""
    conn = await get_db_connection()
    try:
        await conn.execute(
            """INSERT OR REPLACE INTO user_profiles (user_id, username, join_date, commands_used, last_seen) 
               VALUES (?, ?, COALESCE((SELECT join_date FROM user_profiles WHERE user_id = ?), ?), 
                      COALESCE((SELECT commands_used FROM user_profiles WHERE user_id = ?), 0), ?)""",
            (user_id, username, user_id, datetime.now().isoformat(), user_id, datetime.now().isoformat())
        )
        await conn.commit()
    finally:
        await conn.close()

async def increment_command_usage(user_id: int):
    """Increment command usage counter"""
    conn = await get_db_connection()
    try:
        await conn.execute(
            "UPDATE user_profiles SET commands_used = commands_used + 1, last_seen = ? WHERE user_id = ?",
            (datetime.now().isoformat(), user_id)
        )
        await conn.commit()
    finally:
        await conn.close()

async def add_bot_staff(user_id: int, assigned_by: int):
    """Add a bot staff member"""
    conn = await get_db_connection()
    try:
        await conn.execute(
            "INSERT OR REPLACE INTO bot_staff (user_id, assigned_by, assigned_at) VALUES (?, ?, ?)",
            (user_id, assigned_by, datetime.now().isoformat())
        )
        await conn.commit()
    finally:
        await conn.close()

async def is_bot_staff(user_id: int):
    """Check if user is bot staff"""
    conn = await get_db_connection()
    try:
        cursor = await conn.execute(
            "SELECT user_id FROM bot_staff WHERE user_id = ?",
            (user_id,)
        )
        result = await cursor.fetchone()
        return result is not None
    finally:
        await conn.close()

async def add_user_warning(guild_id: int, user_id: int, warned_by: int, reason: str):
    """Add a warning to a user"""
    conn = await get_db_connection()
    try:
        await conn.execute(
            "INSERT INTO user_warnings (guild_id, user_id, warned_by, reason, warned_at) VALUES (?, ?, ?, ?, ?)",
            (guild_id, user_id, warned_by, reason, datetime.now().isoformat())
        )
        await conn.commit()
    finally:
        await conn.close()

async def get_user_warnings(guild_id: int, user_id: int):
    """Get user warnings count"""
    conn = await get_db_connection()
    try:
        cursor = await conn.execute(
            "SELECT COUNT(*) FROM user_warnings WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id)
        )
        result = await cursor.fetchone()
        return result[0] if result else 0
    finally:
        await conn.close()
