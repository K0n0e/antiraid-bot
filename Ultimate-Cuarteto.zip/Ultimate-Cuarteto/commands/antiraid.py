import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timedelta
import asyncio
import logging

from utils.permissions import check_premium
from database import increment_command_usage, get_db_connection

logger = logging.getLogger(__name__)

class AntiRaidCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.raid_detection = {}

    @app_commands.command(name="antiraid", description="Configurar sistema anti-raid")
    @app_commands.describe(
        accion="Acción a realizar",
        valor="Valor para la configuración"
    )
    @app_commands.choices(accion=[
        app_commands.Choice(name="activar", value="enable"),
        app_commands.Choice(name="desactivar", value="disable"),
        app_commands.Choice(name="umbral", value="threshold"),
        app_commands.Choice(name="estado", value="status")
    ])
    @app_commands.default_permissions(administrator=True)
    async def antiraid(self, interaction: discord.Interaction, accion: str, valor: int = None):
        """Configure anti-raid system"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            conn = await get_db_connection()
            
            if accion == "enable":
                await conn.execute(
                    "INSERT OR REPLACE INTO guild_settings (guild_id, antiraid_enabled, created_at) VALUES (?, ?, ?)",
                    (interaction.guild.id, True, datetime.now().isoformat())
                )
                await conn.commit()
                
                embed = discord.Embed(
                    title="🛡️ Anti-Raid Activado",
                    description="El sistema anti-raid ha sido activado en este servidor.",
                    color=0x00ff00
                )
                
            elif accion == "disable":
                await conn.execute(
                    "UPDATE guild_settings SET antiraid_enabled = ? WHERE guild_id = ?",
                    (False, interaction.guild.id)
                )
                await conn.commit()
                
                embed = discord.Embed(
                    title="🛡️ Anti-Raid Desactivado",
                    description="El sistema anti-raid ha sido desactivado en este servidor.",
                    color=0xff0000
                )
                
            elif accion == "threshold":
                if valor is None or valor < 1 or valor > 50:
                    await interaction.response.send_message(
                        "❌ El umbral debe ser entre 1 y 50 usuarios.",
                        ephemeral=True
                    )
                    return
                
                await conn.execute(
                    "UPDATE guild_settings SET raid_detection_threshold = ? WHERE guild_id = ?",
                    (valor, interaction.guild.id)
                )
                await conn.commit()
                
                embed = discord.Embed(
                    title="🛡️ Umbral Anti-Raid Configurado",
                    description=f"El umbral de detección se ha establecido en **{valor}** usuarios por minuto.",
                    color=0x0099ff
                )
                
            elif accion == "status":
                cursor = await conn.execute(
                    "SELECT antiraid_enabled, raid_detection_threshold FROM guild_settings WHERE guild_id = ?",
                    (interaction.guild.id,)
                )
                result = await cursor.fetchone()
                
                if result:
                    enabled, threshold = result
                    status = "✅ Activado" if enabled else "❌ Desactivado"
                    embed = discord.Embed(
                        title="🛡️ Estado Anti-Raid",
                        color=0x0099ff
                    )
                    embed.add_field(name="Estado", value=status, inline=True)
                    embed.add_field(name="Umbral", value=f"{threshold} usuarios/min", inline=True)
                else:
                    embed = discord.Embed(
                        title="🛡️ Anti-Raid No Configurado",
                        description="Usa `/antiraid activar` para comenzar.",
                        color=0xff9900
                    )
            
            await conn.close()
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except Exception as e:
            logger.error(f"Error in antiraid command: {e}")
            await interaction.response.send_message(
                "❌ Error al configurar anti-raid.",
                ephemeral=True
            )

    @app_commands.command(name="lockdown", description="Bloqueo total del servidor")
    @app_commands.describe(razon="Razón del lockdown")
    @app_commands.default_permissions(administrator=True)
    async def lockdown(self, interaction: discord.Interaction, razon: str = "Lockdown activado"):
        """Server lockdown"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            await interaction.response.defer()
            
            locked_channels = 0
            for channel in interaction.guild.text_channels:
                try:
                    overwrite = channel.overwrites_for(interaction.guild.default_role)
                    overwrite.send_messages = False
                    await channel.set_permissions(interaction.guild.default_role, overwrite=overwrite)
                    locked_channels += 1
                except discord.Forbidden:
                    continue
            
            embed = discord.Embed(
                title="🔒 SERVIDOR EN LOCKDOWN",
                description=f"**Razón:** {razon}\n**Canales bloqueados:** {locked_channels}",
                color=0xff0000
            )
            embed.set_footer(text=f"Lockdown activado por {interaction.user.display_name}")
            
            await interaction.followup.send(embed=embed)
            await increment_command_usage(interaction.user.id)

        except Exception as e:
            logger.error(f"Error in lockdown: {e}")
            await interaction.followup.send(
                "❌ Error al activar lockdown.",
                ephemeral=True
            )

    @app_commands.command(name="unlockdown", description="Desbloquear servidor")
    @app_commands.default_permissions(administrator=True)
    async def unlockdown(self, interaction: discord.Interaction):
        """Remove server lockdown"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            await interaction.response.defer()
            
            unlocked_channels = 0
            for channel in interaction.guild.text_channels:
                try:
                    overwrite = channel.overwrites_for(interaction.guild.default_role)
                    overwrite.send_messages = None
                    await channel.set_permissions(interaction.guild.default_role, overwrite=overwrite)
                    unlocked_channels += 1
                except discord.Forbidden:
                    continue
            
            embed = discord.Embed(
                title="🔓 LOCKDOWN DESACTIVADO",
                description=f"**Canales desbloqueados:** {unlocked_channels}",
                color=0x00ff00
            )
            embed.set_footer(text=f"Lockdown desactivado por {interaction.user.display_name}")
            
            await interaction.followup.send(embed=embed)
            await increment_command_usage(interaction.user.id)

        except Exception as e:
            logger.error(f"Error in unlockdown: {e}")
            await interaction.followup.send(
                "❌ Error al desactivar lockdown.",
                ephemeral=True
            )

    @app_commands.command(name="massbam", description="Banear múltiples usuarios por ID")
    @app_commands.describe(
        user_ids="IDs de usuarios separados por espacios",
        razon="Razón del ban masivo"
    )
    @app_commands.default_permissions(ban_members=True)
    async def massban(self, interaction: discord.Interaction, user_ids: str, razon: str = "Ban masivo"):
        """Mass ban users by ID"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            await interaction.response.defer()
            
            ids = user_ids.split()
            if len(ids) > 20:
                await interaction.followup.send(
                    "❌ No puedes banear más de 20 usuarios a la vez.",
                    ephemeral=True
                )
                return

            banned_count = 0
            failed_count = 0
            
            for user_id in ids:
                try:
                    user_id_int = int(user_id)
                    await interaction.guild.ban(
                        discord.Object(id=user_id_int),
                        reason=f"{razon} | Por: {interaction.user}"
                    )
                    banned_count += 1
                except:
                    failed_count += 1
                
                # Rate limit protection
                await asyncio.sleep(0.5)
            
            embed = discord.Embed(
                title="🔨 Ban Masivo Completado",
                description=f"**Baneados:** {banned_count}\n**Fallidos:** {failed_count}\n**Razón:** {razon}",
                color=0xff0000
            )
            embed.set_footer(text=f"Ejecutado por {interaction.user.display_name}")
            
            await interaction.followup.send(embed=embed)
            await increment_command_usage(interaction.user.id)

        except Exception as e:
            logger.error(f"Error in massban: {e}")
            await interaction.followup.send(
                "❌ Error al ejecutar ban masivo.",
                ephemeral=True
            )

    @app_commands.command(name="nuke", description="Recrear canal (eliminar y crear nuevo)")
    @app_commands.describe(canal="Canal a recrear (opcional, por defecto el actual)")
    @app_commands.default_permissions(manage_channels=True)
    async def nuke(self, interaction: discord.Interaction, canal: discord.TextChannel = None):
        """Nuke (recreate) a channel"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        channel = canal or interaction.channel
        
        try:
            # Store channel properties
            name = channel.name
            category = channel.category
            position = channel.position
            overwrites = channel.overwrites
            topic = channel.topic
            slowmode_delay = channel.slowmode_delay
            
            # Create new channel
            new_channel = await channel.clone(reason=f"Canal nukeado por {interaction.user}")
            await new_channel.edit(position=position)
            
            # Delete old channel
            await channel.delete(reason=f"Canal nukeado por {interaction.user}")
            
            embed = discord.Embed(
                title="💥 Canal Nukeado",
                description=f"**Canal:** {new_channel.mention}\n**Ejecutado por:** {interaction.user.mention}",
                color=0xff6600
            )
            
            await new_channel.send(embed=embed)
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para recrear este canal.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error nuking channel: {e}")
            await interaction.response.send_message(
                "❌ Error al nukear el canal.",
                ephemeral=True
            )

    @app_commands.command(name="verify_protection", description="Verificar nivel de protección del servidor")
    @app_commands.default_permissions(administrator=True)
    async def verify_protection(self, interaction: discord.Interaction):
        """Verify server protection level"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            guild = interaction.guild
            protection_score = 0
            issues = []
            
            # Check verification level
            if guild.verification_level >= discord.VerificationLevel.medium:
                protection_score += 20
            else:
                issues.append("❌ Nivel de verificación bajo")
            
            # Check explicit content filter
            if guild.explicit_content_filter != discord.ContentFilter.disabled:
                protection_score += 15
            else:
                issues.append("❌ Filtro de contenido explícito desactivado")
            
            # Check default notifications
            if guild.default_notifications == discord.NotificationLevel.only_mentions:
                protection_score += 10
            else:
                issues.append("❌ Notificaciones por defecto en 'todos los mensajes'")
            
            # Check bot permissions
            bot_member = guild.get_member(self.bot.user.id)
            if bot_member.guild_permissions.ban_members:
                protection_score += 20
            else:
                issues.append("❌ Bot sin permisos de ban")
            
            if bot_member.guild_permissions.kick_members:
                protection_score += 10
            else:
                issues.append("❌ Bot sin permisos de kick")
            
            if bot_member.guild_permissions.manage_messages:
                protection_score += 15
            else:
                issues.append("❌ Bot sin permisos de gestionar mensajes")
            
            if bot_member.guild_permissions.manage_roles:
                protection_score += 10
            else:
                issues.append("❌ Bot sin permisos de gestionar roles")
            
            # Determine protection level
            if protection_score >= 80:
                level = "🟢 ALTO"
                color = 0x00ff00
            elif protection_score >= 60:
                level = "🟡 MEDIO"
                color = 0xffff00
            else:
                level = "🔴 BAJO"
                color = 0xff0000
            
            embed = discord.Embed(
                title="🛡️ Verificación de Protección",
                description=f"**Nivel de protección:** {level}\n**Puntuación:** {protection_score}/100",
                color=color
            )
            
            if issues:
                embed.add_field(
                    name="🔧 Problemas detectados:",
                    value="\n".join(issues),
                    inline=False
                )
            else:
                embed.add_field(
                    name="✅ Estado:",
                    value="Todas las verificaciones pasaron correctamente",
                    inline=False
                )
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except Exception as e:
            logger.error(f"Error in verify_protection: {e}")
            await interaction.response.send_message(
                "❌ Error al verificar protección.",
                ephemeral=True
            )

    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Monitor for potential raids"""
        guild_id = member.guild.id
        now = datetime.now()
        
        # Initialize guild tracking if not exists
        if guild_id not in self.raid_detection:
            self.raid_detection[guild_id] = []
        
        # Add join time
        self.raid_detection[guild_id].append(now)
        
        # Remove joins older than 1 minute
        self.raid_detection[guild_id] = [
            join_time for join_time in self.raid_detection[guild_id]
            if now - join_time < timedelta(minutes=1)
        ]
        
        # Check if threshold exceeded
        try:
            conn = await get_db_connection()
            cursor = await conn.execute(
                "SELECT antiraid_enabled, raid_detection_threshold FROM guild_settings WHERE guild_id = ?",
                (guild_id,)
            )
            result = await cursor.fetchone()
            await conn.close()
            
            if result and result[0]:  # Anti-raid enabled
                threshold = result[1] or 5
                
                if len(self.raid_detection[guild_id]) >= threshold:
                    # Potential raid detected
                    await self.handle_raid_detection(member.guild, len(self.raid_detection[guild_id]))
                    
        except Exception as e:
            logger.error(f"Error in raid detection: {e}")

    async def handle_raid_detection(self, guild, join_count):
        """Handle detected raid"""
        try:
            # Find a channel to send alert
            alert_channel = None
            for channel in guild.text_channels:
                if channel.permissions_for(guild.me).send_messages:
                    alert_channel = channel
                    break
            
            if alert_channel:
                embed = discord.Embed(
                    title="🚨 POSIBLE RAID DETECTADO",
                    description=f"**Detecciones:** {join_count} usuarios en 1 minuto\n**Servidor:** {guild.name}",
                    color=0xff0000
                )
                embed.add_field(
                    name="💡 Sugerencia:",
                    value="Considera usar `/lockdown` si es un raid real.",
                    inline=False
                )
                embed.timestamp = datetime.now()
                
                await alert_channel.send(embed=embed)
                logger.warning(f"Raid detection alert sent in {guild.name} ({guild.id})")
                
        except Exception as e:
            logger.error(f"Error sending raid alert: {e}")

    @app_commands.command(name="whitelist_add", description="Añadir usuario a whitelist del servidor")
    @app_commands.describe(
        usuario="Usuario a añadir a whitelist",
        razon="Razón para añadir a whitelist"
    )
    @app_commands.default_permissions(administrator=True)
    async def whitelist_add(self, interaction: discord.Interaction, usuario: discord.Member, razon: str = "Whitelistado"):
        """Add user to server whitelist"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            conn = await get_db_connection()
            await conn.execute(
                "INSERT OR REPLACE INTO server_whitelist (guild_id, user_id, reason, added_by, added_at) VALUES (?, ?, ?, ?, ?)",
                (interaction.guild.id, usuario.id, razon, interaction.user.id, datetime.now().isoformat())
            )
            await conn.commit()
            await conn.close()
            
            embed = discord.Embed(
                title="✅ Usuario Añadido a Whitelist",
                description=f"**Usuario:** {usuario.mention}\n**Razón:** {razon}",
                color=0x00ff00
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            embed.set_footer(text=f"Añadido por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error adding to whitelist: {e}")
            await interaction.response.send_message(
                "❌ Error al añadir a whitelist.",
                ephemeral=True
            )

    @app_commands.command(name="whitelist_remove", description="Quitar usuario de whitelist")
    @app_commands.describe(usuario="Usuario a quitar de whitelist")
    @app_commands.default_permissions(administrator=True)
    async def whitelist_remove(self, interaction: discord.Interaction, usuario: discord.Member):
        """Remove user from whitelist"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            conn = await get_db_connection()
            cursor = await conn.execute(
                "DELETE FROM server_whitelist WHERE guild_id = ? AND user_id = ?",
                (interaction.guild.id, usuario.id)
            )
            await conn.commit()
            removed = cursor.rowcount > 0
            await conn.close()
            
            if removed:
                embed = discord.Embed(
                    title="❌ Usuario Removido de Whitelist",
                    description=f"**Usuario:** {usuario.mention}",
                    color=0xff9900
                )
                embed.set_thumbnail(url=usuario.display_avatar.url)
                embed.set_footer(text=f"Removido por {interaction.user.display_name}")
            else:
                embed = discord.Embed(
                    title="ℹ️ Usuario No Encontrado",
                    description="El usuario no estaba en la whitelist.",
                    color=0x0099ff
                )
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error removing from whitelist: {e}")
            await interaction.response.send_message(
                "❌ Error al quitar de whitelist.",
                ephemeral=True
            )

    @app_commands.command(name="raid_mode", description="Activar modo raid extremo")
    @app_commands.describe(nivel="Nivel de protección (1-5)")
    @app_commands.default_permissions(administrator=True)
    async def raid_mode(self, interaction: discord.Interaction, nivel: int):
        """Enable extreme raid protection mode"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if nivel < 1 or nivel > 5:
            await interaction.response.send_message(
                "❌ El nivel debe ser entre 1 y 5.",
                ephemeral=True
            )
            return

        try:
            conn = await get_db_connection()
            await conn.execute(
                "UPDATE guild_settings SET raid_mode_level = ?, raid_mode_enabled = ? WHERE guild_id = ?",
                (nivel, True, interaction.guild.id)
            )
            await conn.commit()
            await conn.close()
            
            protections = {
                1: "Básica - Monitoreo de joins",
                2: "Media - Auto-kick usuarios nuevos",
                3: "Alta - Auto-ban usuarios sospechosos",
                4: "Extrema - Lockdown automático",
                5: "Máxima - Bloqueo total de joins"
            }
            
            embed = discord.Embed(
                title="🛡️ MODO RAID ACTIVADO",
                description=f"**Nivel:** {nivel}/5\n**Protección:** {protections[nivel]}",
                color=0xff0000
            )
            embed.add_field(
                name="⚠️ Advertencia",
                value="Este modo puede afectar a usuarios legítimos. Úsalo con precaución.",
                inline=False
            )
            embed.set_footer(text=f"Activado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error enabling raid mode: {e}")
            await interaction.response.send_message(
                "❌ Error al activar modo raid.",
                ephemeral=True
            )

    @app_commands.command(name="raid_mode_off", description="Desactivar modo raid")
    @app_commands.default_permissions(administrator=True)
    async def raid_mode_off(self, interaction: discord.Interaction):
        """Disable raid protection mode"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            conn = await get_db_connection()
            await conn.execute(
                "UPDATE guild_settings SET raid_mode_enabled = ? WHERE guild_id = ?",
                (False, interaction.guild.id)
            )
            await conn.commit()
            await conn.close()
            
            embed = discord.Embed(
                title="✅ Modo Raid Desactivado",
                description="El servidor vuelve a la protección normal.",
                color=0x00ff00
            )
            embed.set_footer(text=f"Desactivado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error disabling raid mode: {e}")
            await interaction.response.send_message(
                "❌ Error al desactivar modo raid.",
                ephemeral=True
            )

    @app_commands.command(name="account_age_limit", description="Configurar límite de antigüedad de cuenta")
    @app_commands.describe(dias="Días mínimos de antigüedad de cuenta (0 para desactivar)")
    @app_commands.default_permissions(administrator=True)
    async def account_age_limit(self, interaction: discord.Interaction, dias: int):
        """Set minimum account age for new members"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if dias < 0 or dias > 365:
            await interaction.response.send_message(
                "❌ Los días deben estar entre 0 y 365.",
                ephemeral=True
            )
            return

        try:
            conn = await get_db_connection()
            await conn.execute(
                "UPDATE guild_settings SET min_account_age_days = ? WHERE guild_id = ?",
                (dias, interaction.guild.id)
            )
            await conn.commit()
            await conn.close()
            
            if dias == 0:
                description = "Límite de antigüedad de cuenta **desactivado**."
                color = 0xff9900
            else:
                description = f"Cuentas menores a **{dias} días** serán rechazadas automáticamente."
                color = 0x00ff00
            
            embed = discord.Embed(
                title="📅 Límite de Antigüedad Configurado",
                description=description,
                color=color
            )
            embed.set_footer(text=f"Configurado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error setting account age limit: {e}")
            await interaction.response.send_message(
                "❌ Error al configurar límite de antigüedad.",
                ephemeral=True
            )

    @app_commands.command(name="auto_dehoist", description="Configurar auto-dehoist de nicknames")
    @app_commands.describe(activar="Activar o desactivar auto-dehoist")
    @app_commands.default_permissions(administrator=True)
    async def auto_dehoist(self, interaction: discord.Interaction, activar: bool):
        """Configure auto-dehoist for hoisted nicknames"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            conn = await get_db_connection()
            await conn.execute(
                "UPDATE guild_settings SET auto_dehoist_enabled = ? WHERE guild_id = ?",
                (activar, interaction.guild.id)
            )
            await conn.commit()
            await conn.close()
            
            status = "activado" if activar else "desactivado"
            color = 0x00ff00 if activar else 0xff9900
            
            embed = discord.Embed(
                title="🔤 Auto-Dehoist Configurado",
                description=f"Auto-dehoist de nicknames **{status}**.",
                color=color
            )
            
            if activar:
                embed.add_field(
                    name="ℹ️ Función",
                    value="Los usuarios con nicknames que comiencen con símbolos especiales serán renombrados automáticamente.",
                    inline=False
                )
            
            embed.set_footer(text=f"Configurado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error configuring auto-dehoist: {e}")
            await interaction.response.send_message(
                "❌ Error al configurar auto-dehoist.",
                ephemeral=True
            )

    @app_commands.command(name="mass_kick_new", description="Expulsar usuarios que se unieron recientemente")
    @app_commands.describe(
        horas="Usuarios que se unieron en las últimas X horas",
        confirmar="Escribe 'CONFIRMAR' para proceder"
    )
    @app_commands.default_permissions(kick_members=True)
    async def mass_kick_new(self, interaction: discord.Interaction, horas: int, confirmar: str):
        """Mass kick recently joined users"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if confirmar.upper() != "CONFIRMAR":
            await interaction.response.send_message(
                "❌ Debes escribir 'CONFIRMAR' para proceder.",
                ephemeral=True
            )
            return

        if horas < 1 or horas > 168:  # Max 1 week
            await interaction.response.send_message(
                "❌ Las horas deben estar entre 1 y 168 (1 semana).",
                ephemeral=True
            )
            return

        try:
            await interaction.response.defer()
            
            cutoff_time = datetime.now() - timedelta(hours=horas)
            kicked_count = 0
            failed_count = 0
            
            for member in interaction.guild.members:
                if member.joined_at and member.joined_at > cutoff_time:
                    # Don't kick bots or admins
                    if not member.bot and not member.guild_permissions.administrator:
                        try:
                            await member.kick(reason=f"Mass kick recientes por {interaction.user}")
                            kicked_count += 1
                            await asyncio.sleep(0.5)
                        except:
                            failed_count += 1
            
            embed = discord.Embed(
                title="👢 Expulsión Masiva de Recientes",
                description=f"**Período:** Últimas {horas} horas\n**Expulsados:** {kicked_count}\n**Fallidos:** {failed_count}",
                color=0xff9900
            )
            embed.set_footer(text=f"Ejecutado por {interaction.user.display_name}")
            
            await interaction.followup.send(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error mass kicking new users: {e}")
            await interaction.followup.send(
                "❌ Error al expulsar usuarios recientes.",
                ephemeral=True
            )

    @app_commands.command(name="channel_clone", description="Clonar canal con permisos")
    @app_commands.describe(
        canal="Canal a clonar (opcional, por defecto el actual)",
        nombre="Nuevo nombre para el canal clonado"
    )
    @app_commands.default_permissions(manage_channels=True)
    async def channel_clone(self, interaction: discord.Interaction, canal: discord.TextChannel = None, nombre: str = None):
        """Clone channel with permissions"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        channel = canal or interaction.channel
        new_name = nombre or f"{channel.name}-clone"
        
        try:
            cloned = await channel.clone(name=new_name, reason=f"Canal clonado por {interaction.user}")
            
            embed = discord.Embed(
                title="📋 Canal Clonado",
                description=f"**Original:** {channel.mention}\n**Clon:** {cloned.mention}",
                color=0x0099ff
            )
            embed.set_footer(text=f"Clonado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para clonar canales.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error cloning channel: {e}")
            await interaction.response.send_message(
                "❌ Error al clonar canal.",
                ephemeral=True
            )

    @app_commands.command(name="backup_channels", description="Crear backup de configuración de canales")
    @app_commands.default_permissions(administrator=True)
    async def backup_channels(self, interaction: discord.Interaction):
        """Create backup of channel configuration"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            await interaction.response.defer()
            
            backup_data = {
                'guild_id': interaction.guild.id,
                'guild_name': interaction.guild.name,
                'channels': [],
                'categories': [],
                'created_at': datetime.now().isoformat()
            }
            
            # Backup categories
            for category in interaction.guild.categories:
                backup_data['categories'].append({
                    'name': category.name,
                    'position': category.position,
                    'overwrites': {str(k.id): {perm: value for perm, value in v} for k, v in category.overwrites.items()}
                })
            
            # Backup channels
            for channel in interaction.guild.text_channels:
                backup_data['channels'].append({
                    'name': channel.name,
                    'topic': channel.topic,
                    'position': channel.position,
                    'category': channel.category.name if channel.category else None,
                    'slowmode_delay': channel.slowmode_delay,
                    'overwrites': {str(k.id): {perm: value for perm, value in v} for k, v in channel.overwrites.items()}
                })
            
            # Store backup in database
            conn = await get_db_connection()
            await conn.execute(
                "INSERT INTO channel_backups (guild_id, backup_data, created_by, created_at) VALUES (?, ?, ?, ?)",
                (interaction.guild.id, str(backup_data), interaction.user.id, datetime.now().isoformat())
            )
            await conn.commit()
            await conn.close()
            
            embed = discord.Embed(
                title="💾 Backup de Canales Creado",
                description=f"**Categorías:** {len(backup_data['categories'])}\n**Canales:** {len(backup_data['channels'])}",
                color=0x00ff00
            )
            embed.add_field(
                name="ℹ️ Información",
                value="El backup incluye nombres, permisos, posiciones y configuraciones.",
                inline=False
            )
            embed.set_footer(text=f"Creado por {interaction.user.display_name}")
            
            await interaction.followup.send(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error creating channel backup: {e}")
            await interaction.followup.send(
                "❌ Error al crear backup de canales.",
                ephemeral=True
            )

    @app_commands.command(name="anti_invite", description="Configurar protección anti-invitaciones")
    @app_commands.describe(
        activar="Activar o desactivar anti-invitaciones",
        accion="Acción a tomar (delete/kick/ban)"
    )
    @app_commands.choices(accion=[
        app_commands.Choice(name="Eliminar mensaje", value="delete"),
        app_commands.Choice(name="Expulsar usuario", value="kick"),
        app_commands.Choice(name="Banear usuario", value="ban")
    ])
    @app_commands.default_permissions(administrator=True)
    async def anti_invite(self, interaction: discord.Interaction, activar: bool, accion: str = "delete"):
        """Configure anti-invite protection"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            conn = await get_db_connection()
            await conn.execute(
                "UPDATE guild_settings SET anti_invite_enabled = ?, anti_invite_action = ? WHERE guild_id = ?",
                (activar, accion, interaction.guild.id)
            )
            await conn.commit()
            await conn.close()
            
            status = "activada" if activar else "desactivada"
            color = 0x00ff00 if activar else 0xff9900
            
            embed = discord.Embed(
                title="🔗 Protección Anti-Invitaciones",
                description=f"Protección **{status}**.",
                color=color
            )
            
            if activar:
                acciones = {
                    "delete": "Eliminar mensaje",
                    "kick": "Expulsar usuario", 
                    "ban": "Banear usuario"
                }
                embed.add_field(
                    name="⚡ Acción",
                    value=acciones[accion],
                    inline=True
                )
            
            embed.set_footer(text=f"Configurado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error configuring anti-invite: {e}")
            await interaction.response.send_message(
                "❌ Error al configurar anti-invitaciones.",
                ephemeral=True
            )

    @app_commands.command(name="anti_spam", description="Configurar protección anti-spam")
    @app_commands.describe(
        activar="Activar o desactivar anti-spam",
        limite="Límite de mensajes por minuto",
        accion="Acción a tomar contra spammers"
    )
    @app_commands.choices(accion=[
        app_commands.Choice(name="Timeout 10 min", value="timeout"),
        app_commands.Choice(name="Expulsar", value="kick"),
        app_commands.Choice(name="Banear", value="ban")
    ])
    @app_commands.default_permissions(administrator=True)
    async def anti_spam(self, interaction: discord.Interaction, activar: bool, limite: int = 10, accion: str = "timeout"):
        """Configure anti-spam protection"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if limite < 1 or limite > 50:
            await interaction.response.send_message(
                "❌ El límite debe estar entre 1 y 50 mensajes por minuto.",
                ephemeral=True
            )
            return

        try:
            conn = await get_db_connection()
            await conn.execute(
                "UPDATE guild_settings SET anti_spam_enabled = ?, anti_spam_limit = ?, anti_spam_action = ? WHERE guild_id = ?",
                (activar, limite, accion, interaction.guild.id)
            )
            await conn.commit()
            await conn.close()
            
            status = "activada" if activar else "desactivada"
            color = 0x00ff00 if activar else 0xff9900
            
            embed = discord.Embed(
                title="🚫 Protección Anti-Spam",
                description=f"Protección **{status}**.",
                color=color
            )
            
            if activar:
                acciones = {
                    "timeout": "Timeout 10 minutos",
                    "kick": "Expulsar usuario",
                    "ban": "Banear usuario"
                }
                embed.add_field(
                    name="📊 Configuración",
                    value=f"**Límite:** {limite} mensajes/min\n**Acción:** {acciones[accion]}",
                    inline=False
                )
            
            embed.set_footer(text=f"Configurado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error configuring anti-spam: {e}")
            await interaction.response.send_message(
                "❌ Error al configurar anti-spam.",
                ephemeral=True
            )

    @app_commands.command(name="join_logs", description="Configurar logs de usuarios que se unen/salen")
    @app_commands.describe(
        canal="Canal para los logs de joins/leaves",
        activar="Activar o desactivar logs"
    )
    @app_commands.default_permissions(administrator=True)
    async def join_logs(self, interaction: discord.Interaction, canal: discord.TextChannel = None, activar: bool = True):
        """Configure join/leave logs"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            conn = await get_db_connection()
            if canal and activar:
                await conn.execute(
                    "UPDATE guild_settings SET join_logs_enabled = ?, join_logs_channel = ? WHERE guild_id = ?",
                    (True, canal.id, interaction.guild.id)
                )
                description = f"Logs de joins/leaves **activados** en {canal.mention}."
                color = 0x00ff00
            else:
                await conn.execute(
                    "UPDATE guild_settings SET join_logs_enabled = ? WHERE guild_id = ?",
                    (False, interaction.guild.id)
                )
                description = "Logs de joins/leaves **desactivados**."
                color = 0xff9900
            
            await conn.commit()
            await conn.close()
            
            embed = discord.Embed(
                title="📋 Logs de Joins/Leaves",
                description=description,
                color=color
            )
            embed.set_footer(text=f"Configurado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error configuring join logs: {e}")
            await interaction.response.send_message(
                "❌ Error al configurar logs.",
                ephemeral=True
            )

    @app_commands.command(name="auto_role", description="Configurar rol automático para nuevos usuarios")
    @app_commands.describe(
        rol="Rol a dar automáticamente",
        activar="Activar o desactivar auto-rol"
    )
    @app_commands.default_permissions(administrator=True)
    async def auto_role(self, interaction: discord.Interaction, rol: discord.Role = None, activar: bool = True):
        """Configure automatic role for new members"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            conn = await get_db_connection()
            if rol and activar:
                await conn.execute(
                    "UPDATE guild_settings SET auto_role_enabled = ?, auto_role_id = ? WHERE guild_id = ?",
                    (True, rol.id, interaction.guild.id)
                )
                description = f"Auto-rol **activado**: {rol.mention}"
                color = 0x00ff00
            else:
                await conn.execute(
                    "UPDATE guild_settings SET auto_role_enabled = ? WHERE guild_id = ?",
                    (False, interaction.guild.id)
                )
                description = "Auto-rol **desactivado**."
                color = 0xff9900
            
            await conn.commit()
            await conn.close()
            
            embed = discord.Embed(
                title="🎖️ Auto-Rol Configurado",
                description=description,
                color=color
            )
            
            if rol and activar:
                embed.add_field(
                    name="ℹ️ Información",
                    value="Los nuevos miembros recibirán este rol automáticamente al unirse.",
                    inline=False
                )
            
            embed.set_footer(text=f"Configurado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error configuring auto role: {e}")
            await interaction.response.send_message(
                "❌ Error al configurar auto-rol.",
                ephemeral=True
            )

    @app_commands.command(name="captcha_verify", description="Configurar verificación por captcha")
    @app_commands.describe(
        activar="Activar o desactivar captcha",
        canal="Canal de verificación"
    )
    @app_commands.default_permissions(administrator=True)
    async def captcha_verify(self, interaction: discord.Interaction, activar: bool, canal: discord.TextChannel = None):
        """Configure captcha verification for new members"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            conn = await get_db_connection()
            if activar and canal:
                await conn.execute(
                    "UPDATE guild_settings SET captcha_enabled = ?, captcha_channel = ? WHERE guild_id = ?",
                    (True, canal.id, interaction.guild.id)
                )
                description = f"Verificación por captcha **activada** en {canal.mention}."
                color = 0x00ff00
            else:
                await conn.execute(
                    "UPDATE guild_settings SET captcha_enabled = ? WHERE guild_id = ?",
                    (False, interaction.guild.id)
                )
                description = "Verificación por captcha **desactivada**."
                color = 0xff9900
            
            await conn.commit()
            await conn.close()
            
            embed = discord.Embed(
                title="🔐 Verificación por Captcha",
                description=description,
                color=color
            )
            
            if activar and canal:
                embed.add_field(
                    name="ℹ️ Funcionamiento",
                    value="Los nuevos usuarios deberán resolver un captcha antes de acceder al servidor.",
                    inline=False
                )
            
            embed.set_footer(text=f"Configurado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error configuring captcha: {e}")
            await interaction.response.send_message(
                "❌ Error al configurar captcha.",
                ephemeral=True
            )

    @app_commands.command(name="server_backup", description="Crear backup completo del servidor")
    @app_commands.describe(incluir_mensajes="Incluir mensajes recientes en el backup")
    @app_commands.default_permissions(administrator=True)
    async def server_backup(self, interaction: discord.Interaction, incluir_mensajes: bool = False):
        """Create complete server backup"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            await interaction.response.defer()
            
            guild = interaction.guild
            backup_data = {
                'guild_info': {
                    'name': guild.name,
                    'description': guild.description,
                    'verification_level': str(guild.verification_level),
                    'explicit_content_filter': str(guild.explicit_content_filter),
                    'default_notifications': str(guild.default_notifications)
                },
                'roles': [],
                'channels': [],
                'categories': [],
                'created_at': datetime.now().isoformat()
            }
            
            # Backup roles
            for role in guild.roles:
                if role != guild.default_role:
                    backup_data['roles'].append({
                        'name': role.name,
                        'color': role.color.value,
                        'permissions': role.permissions.value,
                        'hoist': role.hoist,
                        'mentionable': role.mentionable,
                        'position': role.position
                    })
            
            # Store backup
            conn = await get_db_connection()
            await conn.execute(
                "INSERT INTO server_backups (guild_id, backup_data, created_by, created_at, includes_messages) VALUES (?, ?, ?, ?, ?)",
                (guild.id, str(backup_data), interaction.user.id, datetime.now().isoformat(), incluir_mensajes)
            )
            await conn.commit()
            await conn.close()
            
            embed = discord.Embed(
                title="💾 Backup del Servidor Creado",
                description="Backup completo del servidor guardado exitosamente.",
                color=0x00ff00
            )
            embed.add_field(
                name="📊 Elementos incluidos",
                value=f"**Roles:** {len(backup_data['roles'])}\n**Canales:** {len(backup_data['channels'])}\n**Categorías:** {len(backup_data['categories'])}",
                inline=True
            )
            embed.add_field(
                name="⚙️ Configuración",
                value="Incluye permisos, configuración del servidor y estructura de canales.",
                inline=True
            )
            embed.set_footer(text=f"Creado por {interaction.user.display_name}")
            
            await interaction.followup.send(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error creating server backup: {e}")
            await interaction.followup.send(
                "❌ Error al crear backup del servidor.",
                ephemeral=True
            )

    @app_commands.command(name="raid_stats", description="Ver estadísticas de raids detectados")
    @app_commands.default_permissions(administrator=True)
    async def raid_stats(self, interaction: discord.Interaction):
        """Show raid detection statistics"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            guild_id = interaction.guild.id
            current_joins = len(self.raid_detection.get(guild_id, []))
            
            conn = await get_db_connection()
            cursor = await conn.execute(
                "SELECT antiraid_enabled, raid_detection_threshold, raid_mode_enabled, raid_mode_level FROM guild_settings WHERE guild_id = ?",
                (guild_id,)
            )
            settings = await cursor.fetchone()
            await conn.close()
            
            embed = discord.Embed(
                title="📈 Estadísticas Anti-Raid",
                color=0x0099ff
            )
            
            if settings:
                antiraid_enabled, threshold, raid_mode, raid_level = settings
                
                status = "✅ Activado" if antiraid_enabled else "❌ Desactivado"
                embed.add_field(
                    name="🛡️ Estado",
                    value=status,
                    inline=True
                )
                
                embed.add_field(
                    name="⚡ Umbral",
                    value=f"{threshold} usuarios/min",
                    inline=True
                )
                
                if raid_mode:
                    embed.add_field(
                        name="🔴 Modo Raid",
                        value=f"Nivel {raid_level}/5",
                        inline=True
                    )
            
            embed.add_field(
                name="📅 Joins Recientes",
                value=f"{current_joins} en el último minuto",
                inline=True
            )
            
            embed.add_field(
                name="📊 Miembros Totales",
                value=str(interaction.guild.member_count),
                inline=True
            )
            
            embed.set_footer(text=f"Consultado por {interaction.user.display_name}")
            embed.timestamp = datetime.now()
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error showing raid stats: {e}")
            await interaction.response.send_message(
                "❌ Error al cargar estadísticas.",
                ephemeral=True
            )

    @app_commands.command(name="emergency_lock", description="Bloqueo de emergencia total del servidor")
    @app_commands.describe(codigo="Escribe 'EMERGENCIA' para activar")
    @app_commands.default_permissions(administrator=True)
    async def emergency_lock(self, interaction: discord.Interaction, codigo: str):
        """Emergency server lockdown"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if codigo.upper() != "EMERGENCIA":
            await interaction.response.send_message(
                "❌ Debes escribir 'EMERGENCIA' para activar el bloqueo de emergencia.",
                ephemeral=True
            )
            return

        try:
            await interaction.response.defer()
            
            guild = interaction.guild
            actions_taken = []
            
            # Lock all text channels
            locked_channels = 0
            for channel in guild.text_channels:
                try:
                    overwrite = channel.overwrites_for(guild.default_role)
                    overwrite.send_messages = False
                    overwrite.add_reactions = False
                    overwrite.create_public_threads = False
                    await channel.set_permissions(guild.default_role, overwrite=overwrite)
                    locked_channels += 1
                except:
                    continue
            
            if locked_channels > 0:
                actions_taken.append(f"\ud83d\udd12 {locked_channels} canales bloqueados")
            
            # Disconnect all voice users
            disconnected = 0
            for member in guild.members:
                if member.voice:
                    try:
                        await member.move_to(None, reason="Bloqueo de emergencia")
                        disconnected += 1
                    except:
                        continue
            
            if disconnected > 0:
                actions_taken.append(f"\ud83d\udd0a {disconnected} usuarios desconectados de voz")
            
            # Store emergency lock status
            conn = await get_db_connection()
            await conn.execute(
                "UPDATE guild_settings SET emergency_lock = ?, emergency_lock_by = ?, emergency_lock_at = ? WHERE guild_id = ?",
                (True, interaction.user.id, datetime.now().isoformat(), guild.id)
            )
            await conn.commit()
            await conn.close()
            
            embed = discord.Embed(
                title="🆘 BLOQUEO DE EMERGENCIA ACTIVADO",
                description="El servidor ha sido bloqueado completamente por medidas de emergencia.",
                color=0xff0000
            )
            
            if actions_taken:
                embed.add_field(
                    name="⚙️ Acciones Realizadas",
                    value="\n".join(actions_taken),
                    inline=False
                )
            
            embed.add_field(
                name="⚠️ Importante",
                value="Usa `/emergency_unlock` para desbloquear cuando la emergencia haya pasado.",
                inline=False
            )
            
            embed.set_footer(text=f"Activado por {interaction.user.display_name}")
            embed.timestamp = datetime.now()
            
            await interaction.followup.send(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error in emergency lock: {e}")
            await interaction.followup.send(
                "❌ Error al activar bloqueo de emergencia.",
                ephemeral=True
            )

    @app_commands.command(name="emergency_unlock", description="Desbloquear servidor tras emergencia")
    @app_commands.default_permissions(administrator=True)
    async def emergency_unlock(self, interaction: discord.Interaction):
        """Remove emergency server lockdown"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            await interaction.response.defer()
            
            guild = interaction.guild
            
            # Check if emergency lock is active
            conn = await get_db_connection()
            cursor = await conn.execute(
                "SELECT emergency_lock FROM guild_settings WHERE guild_id = ?",
                (guild.id,)
            )
            result = await cursor.fetchone()
            
            if not result or not result[0]:
                embed = discord.Embed(
                    title="ℹ️ No hay bloqueo de emergencia",
                    description="No hay un bloqueo de emergencia activo en este servidor.",
                    color=0x0099ff
                )
                await interaction.followup.send(embed=embed)
                return
            
            # Unlock all text channels
            unlocked_channels = 0
            for channel in guild.text_channels:
                try:
                    overwrite = channel.overwrites_for(guild.default_role)
                    overwrite.send_messages = None
                    overwrite.add_reactions = None
                    overwrite.create_public_threads = None
                    await channel.set_permissions(guild.default_role, overwrite=overwrite)
                    unlocked_channels += 1
                except:
                    continue
            
            # Remove emergency lock status
            await conn.execute(
                "UPDATE guild_settings SET emergency_lock = ?, emergency_unlock_by = ?, emergency_unlock_at = ? WHERE guild_id = ?",
                (False, interaction.user.id, datetime.now().isoformat(), guild.id)
            )
            await conn.commit()
            await conn.close()
            
            embed = discord.Embed(
                title="✅ BLOQUEO DE EMERGENCIA DESACTIVADO",
                description="El servidor ha sido desbloqueado y vuelve a la normalidad.",
                color=0x00ff00
            )
            embed.add_field(
                name="⚙️ Acciones Realizadas",
                value=f"\ud83d\udd13 {unlocked_channels} canales desbloqueados",
                inline=False
            )
            embed.set_footer(text=f"Desactivado por {interaction.user.display_name}")
            embed.timestamp = datetime.now()
            
            await interaction.followup.send(embed=embed)
            await increment_command_usage(interaction.user.id)
            
        except Exception as e:
            logger.error(f"Error in emergency unlock: {e}")
            await interaction.followup.send(
                "❌ Error al desactivar bloqueo de emergencia.",
                ephemeral=True
            )
