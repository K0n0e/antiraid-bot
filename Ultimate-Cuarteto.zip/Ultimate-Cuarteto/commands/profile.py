import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime
import logging

from database import (
    get_db_connection, update_user_profile, increment_command_usage,
    is_premium_user, is_bot_admin, add_bot_admin, is_blacklisted
)
from utils.permissions import is_founder, check_premium
from config import FOUNDER_ID

logger = logging.getLogger(__name__)

class ProfileCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="perfil", description="Ver perfil global de un usuario")
    @app_commands.describe(usuario="Usuario a consultar (opcional, por defecto tú)")
    async def perfil(self, interaction: discord.Interaction, usuario: discord.Member = None):
        """Show user's global profile"""
        target_user = usuario or interaction.user
        
        try:
            # Update profile data
            await update_user_profile(target_user.id, str(target_user))
            
            # Get user data from database
            conn = await get_db_connection()
            
            # Get profile data
            cursor = await conn.execute(
                "SELECT join_date, commands_used, last_seen FROM user_profiles WHERE user_id = ?",
                (target_user.id,)
            )
            profile_data = await cursor.fetchone()
            
            # Get premium status
            is_premium = await is_premium_user(target_user.id)
            premium_cursor = await conn.execute(
                "SELECT expires_at, activated_at FROM premium_users WHERE user_id = ?",
                (target_user.id,)
            )
            premium_data = await premium_cursor.fetchone()
            
            # Check roles
            is_admin = await is_bot_admin(target_user.id)
            is_founder_user = is_founder(target_user.id)
            is_blacklisted_user = await is_blacklisted(target_user.id)
            
            # Check if user is staff
            staff_cursor = await conn.execute(
                "SELECT user_id FROM bot_staff WHERE user_id = ?", 
                (target_user.id,)
            )
            staff_result = await staff_cursor.fetchone()
            is_staff = staff_result is not None
            
            await conn.close()
            
            # Create embed with special founder treatment
            if is_founder_user:
                embed = discord.Embed(
                    title=f"👑 {target_user.display_name}",
                    description="**Fundador oficial de Cuarteto Squad**",
                    color=0xffd700
                )
            else:
                embed = discord.Embed(
                    title=f"👤 Perfil de {target_user.display_name}",
                    color=0x0099ff
                )
            embed.set_thumbnail(url=target_user.display_avatar.url)
            
            # Basic info
            embed.add_field(
                name="📊 Información Básica",
                value=f"**ID:** `{target_user.id}`\n**Mención:** {target_user.mention}",
                inline=False
            )
            
            # Bot roles with enhanced founder display
            roles = []
            if is_founder_user:
                roles.append("👑 **FUNDADOR DE CUARTETO SQUAD**")
            if is_admin:
                roles.append("🛡️ **ADMIN DEL BOT**")
            
            if roles:
                embed.add_field(
                    name="🎭 Roles del Bot",
                    value="\n".join(roles),
                    inline=True
                )
            
            # Premium status
            if is_premium:
                if premium_data:
                    expires_at = premium_data[0]
                    activated_at = premium_data[1]
                    
                    premium_text = "✅ **PREMIUM ACTIVO**\n"
                    if expires_at:
                        try:
                            expire_date = datetime.fromisoformat(expires_at)
                            premium_text += f"**Expira:** {expire_date.strftime('%d/%m/%Y %H:%M')}"
                        except:
                            premium_text += "**Expira:** Error al cargar fecha"
                    else:
                        premium_text += "**Tipo:** LIFETIME"
                else:
                    premium_text = "✅ **PREMIUM ACTIVO**"
            else:
                premium_text = "❌ **NO PREMIUM**"
            
            embed.add_field(
                name="💎 Estado Premium",
                value=premium_text,
                inline=True
            )
            
            # Usage stats
            if profile_data:
                join_date, commands_used, last_seen = profile_data
                try:
                    join_dt = datetime.fromisoformat(join_date)
                    join_formatted = join_dt.strftime('%d/%m/%Y')
                except:
                    join_formatted = "Desconocido"
                
                try:
                    last_seen_dt = datetime.fromisoformat(last_seen)
                    last_seen_formatted = last_seen_dt.strftime('%d/%m/%Y %H:%M')
                except:
                    last_seen_formatted = "Desconocido"
                
                embed.add_field(
                    name="📈 Estadísticas",
                    value=f"**Registrado:** {join_formatted}\n**Comandos usados:** {commands_used}\n**Última vez visto:** {last_seen_formatted}",
                    inline=False
                )
            
            # Blacklist status
            if is_blacklisted_user:
                embed.add_field(
                    name="🚫 Estado",
                    value="**BLACKLISTED**",
                    inline=True
                )
                embed.color = 0xff0000
            
            # Discord account info
            account_created = target_user.created_at.strftime('%d/%m/%Y')
            embed.add_field(
                name="📅 Cuenta de Discord",
                value=f"**Creada:** {account_created}",
                inline=True
            )
            
            embed.set_footer(text=f"Consultado por {interaction.user.display_name}")
            embed.timestamp = datetime.now()
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except Exception as e:
            logger.error(f"Error showing profile: {e}")
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(
                        "❌ Error al cargar el perfil.",
                        ephemeral=True
                    )
                else:
                    await interaction.followup.send(
                        "❌ Error al cargar el perfil.",
                        ephemeral=True
                    )
            except:
                pass

    @app_commands.command(name="use_key", description="Usar una key premium")
    @app_commands.describe(key="Key premium a usar")
    async def use_key(self, interaction: discord.Interaction, key: str):
        """Use a premium key"""
        try:
            from database import use_premium_key
            
            success = await use_premium_key(key, interaction.user.id)
            
            if success:
                embed = discord.Embed(
                    title="✅ Key Activada",
                    description="¡Tu key premium ha sido activada correctamente!",
                    color=0x00ff00
                )
                embed.add_field(
                    name="💎 Estado",
                    value="Ya puedes usar todos los comandos premium del bot.",
                    inline=False
                )
                embed.set_footer(text="¡Disfruta de tu premium!")
                
                if not interaction.response.is_done():
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                else:
                    await interaction.followup.send(embed=embed, ephemeral=True)
                logger.info(f"Premium key used by {interaction.user} ({interaction.user.id})")
                
            else:
                embed = discord.Embed(
                    title="❌ Key Inválida",
                    description="La key proporcionada no es válida o ya ha sido usada.",
                    color=0xff0000
                )
                if not interaction.response.is_done():
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                else:
                    await interaction.followup.send(embed=embed, ephemeral=True)

        except Exception as e:
            logger.error(f"Error using premium key: {e}")
            await interaction.response.send_message(
                "❌ Error al procesar la key.",
                ephemeral=True
            )

    @app_commands.command(name="dar_staff", description="Dar rol de staff a un usuario")
    @app_commands.describe(usuario="Usuario al que dar staff")
    async def dar_staff(self, interaction: discord.Interaction, usuario: discord.Member):
        """Give staff role to user"""
        if not (is_founder(interaction.user.id) or await is_bot_admin(interaction.user.id)):
            await interaction.response.send_message(
                "❌ Solo el fundador y los admins pueden usar este comando.",
                ephemeral=True
            )
            return

        try:
            conn = await get_db_connection()
            await conn.execute(
                "INSERT OR REPLACE INTO bot_staff (user_id, assigned_by, assigned_at) VALUES (?, ?, ?)",
                (usuario.id, interaction.user.id, datetime.now().isoformat())
            )
            await conn.commit()
            await conn.close()
            
            embed = discord.Embed(
                title="⭐ Staff Asignado",
                description=f"{usuario.mention} ahora tiene rol de staff del bot.",
                color=0x9932cc
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            embed.set_footer(text=f"Asignado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            logger.info(f"Staff role given to {usuario} by {interaction.user}")

        except Exception as e:
            logger.error(f"Error giving staff role: {e}")
            await interaction.response.send_message(
                "❌ Error al asignar staff.",
                ephemeral=True
            )

    @app_commands.command(name="quitar_staff", description="Quitar rol de staff a un usuario")
    @app_commands.describe(usuario="Usuario al que quitar staff")
    async def quitar_staff(self, interaction: discord.Interaction, usuario: discord.Member):
        """Remove staff role from user"""
        if not (is_founder(interaction.user.id) or await is_bot_admin(interaction.user.id)):
            await interaction.response.send_message(
                "❌ Solo el fundador y los admins pueden usar este comando.",
                ephemeral=True
            )
            return

        try:
            conn = await get_db_connection()
            cursor = await conn.execute(
                "DELETE FROM bot_staff WHERE user_id = ?",
                (usuario.id,)
            )
            await conn.commit()
            
            if cursor.rowcount > 0:
                embed = discord.Embed(
                    title="❌ Staff Removido",
                    description=f"Se ha removido el rol de staff de {usuario.mention}.",
                    color=0xff9900
                )
                embed.set_thumbnail(url=usuario.display_avatar.url)
                embed.set_footer(text=f"Removido por {interaction.user.display_name}")
                
                await interaction.response.send_message(embed=embed)
                logger.info(f"Staff role removed from {usuario} by {interaction.user}")
            else:
                await interaction.response.send_message(
                    "❌ Este usuario no tiene rol de staff.",
                    ephemeral=True
                )
            
            await conn.close()

        except Exception as e:
            logger.error(f"Error removing staff role: {e}")
            await interaction.response.send_message(
                "❌ Error al quitar staff.",
                ephemeral=True
            )

    @app_commands.command(name="lista_staff", description="Ver lista de staff del bot")
    async def lista_staff(self, interaction: discord.Interaction):
        """Show bot staff list"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            conn = await get_db_connection()
            
            # Get admins
            admin_cursor = await conn.execute("SELECT user_id FROM bot_admins")
            admin_ids = [row[0] for row in await admin_cursor.fetchall()]
            
            # Get staff
            staff_cursor = await conn.execute("SELECT user_id FROM bot_staff")
            staff_ids = [row[0] for row in await staff_cursor.fetchall()]
            
            await conn.close()
            
            embed = discord.Embed(
                title="👥 Staff del Bot",
                color=0x9932cc
            )
            
            # Founder
            founder_user = self.bot.get_user(FOUNDER_ID)
            founder_name = founder_user.mention if founder_user else f"<@{FOUNDER_ID}>"
            embed.add_field(
                name="👑 Fundador",
                value=founder_name,
                inline=False
            )
            
            # Admins
            if admin_ids:
                admin_mentions = []
                for admin_id in admin_ids:
                    user = self.bot.get_user(admin_id)
                    admin_mentions.append(user.mention if user else f"<@{admin_id}>")
                
                embed.add_field(
                    name="🛡️ Admins",
                    value="\n".join(admin_mentions),
                    inline=False
                )
            
            # Staff
            if staff_ids:
                staff_mentions = []
                for staff_id in staff_ids:
                    user = self.bot.get_user(staff_id)
                    staff_mentions.append(user.mention if user else f"<@{staff_id}>")
                
                embed.add_field(
                    name="⭐ Staff",
                    value="\n".join(staff_mentions),
                    inline=False
                )
            
            if not admin_ids and not staff_ids:
                embed.add_field(
                    name="ℹ️ Estado",
                    value="Solo está configurado el fundador.",
                    inline=False
                )
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except Exception as e:
            logger.error(f"Error showing staff list: {e}")
            await interaction.response.send_message(
                "❌ Error al cargar lista de staff.",
                ephemeral=True
            )
