import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timedelta
import asyncio
import logging

from utils.permissions import check_premium
from database import increment_command_usage

logger = logging.getLogger(__name__)

class ModerationCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_app_command_error(self, interaction: discord.Interaction, error):
        """Handle moderation command errors"""
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message(
                "❌ No tienes permisos para usar este comando.",
                ephemeral=True
            )
        elif isinstance(error, app_commands.BotMissingPermissions):
            await interaction.response.send_message(
                "❌ El bot no tiene permisos suficientes para ejecutar esta acción.",
                ephemeral=True
            )

    @app_commands.command(name="ban", description="Banear un usuario")
    @app_commands.describe(
        usuario="Usuario a banear",
        razon="Razón del ban",
        delete_days="Días de mensajes a eliminar (0-7)"
    )
    @app_commands.default_permissions(ban_members=True)
    async def ban(self, interaction: discord.Interaction, usuario: discord.Member, razon: str = "No especificada", delete_days: int = 0):
        """Ban a user"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if delete_days < 0 or delete_days > 7:
            delete_days = 0

        # Check hierarchy
        if usuario.top_role >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
            await interaction.response.send_message(
                "❌ No puedes banear a este usuario (jerarquía de roles).",
                ephemeral=True
            )
            return

        try:
            await usuario.ban(reason=f"{razon} | Por: {interaction.user}", delete_message_days=delete_days)
            
            embed = discord.Embed(
                title="🔨 Usuario Baneado",
                description=f"**Usuario:** {usuario.mention}\n**Razón:** {razon}",
                color=0xff0000
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            embed.set_footer(text=f"Baneado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)
            
            logger.info(f"User {usuario} banned by {interaction.user} in {interaction.guild.name}")

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para banear a este usuario.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error banning user: {e}")
            await interaction.response.send_message(
                "❌ Error al banear el usuario.",
                ephemeral=True
            )

    @app_commands.command(name="kick", description="Expulsar un usuario")
    @app_commands.describe(
        usuario="Usuario a expulsar",
        razon="Razón de la expulsión"
    )
    @app_commands.default_permissions(kick_members=True)
    async def kick(self, interaction: discord.Interaction, usuario: discord.Member, razon: str = "No especificada"):
        """Kick a user"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        # Check hierarchy
        if usuario.top_role >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
            await interaction.response.send_message(
                "❌ No puedes expulsar a este usuario (jerarquía de roles).",
                ephemeral=True
            )
            return

        try:
            await usuario.kick(reason=f"{razon} | Por: {interaction.user}")
            
            embed = discord.Embed(
                title="👢 Usuario Expulsado",
                description=f"**Usuario:** {usuario.mention}\n**Razón:** {razon}",
                color=0xff9900
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            embed.set_footer(text=f"Expulsado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para expulsar a este usuario.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error kicking user: {e}")
            await interaction.response.send_message(
                "❌ Error al expulsar el usuario.",
                ephemeral=True
            )

    @app_commands.command(name="timeout", description="Silenciar un usuario temporalmente")
    @app_commands.describe(
        usuario="Usuario a silenciar",
        duracion="Duración en minutos (máximo 40320 = 28 días)",
        razon="Razón del timeout"
    )
    @app_commands.default_permissions(moderate_members=True)
    async def timeout(self, interaction: discord.Interaction, usuario: discord.Member, duracion: int, razon: str = "No especificada"):
        """Timeout a user"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        # Check duration limits
        if duracion <= 0 or duracion > 40320:  # 28 days max
            await interaction.response.send_message(
                "❌ La duración debe ser entre 1 y 40320 minutos (28 días).",
                ephemeral=True
            )
            return

        # Check hierarchy
        if usuario.top_role >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
            await interaction.response.send_message(
                "❌ No puedes silenciar a este usuario (jerarquía de roles).",
                ephemeral=True
            )
            return

        try:
            timeout_until = datetime.now() + timedelta(minutes=duracion)
            await usuario.timeout(timeout_until, reason=f"{razon} | Por: {interaction.user}")
            
            embed = discord.Embed(
                title="🔇 Usuario Silenciado",
                description=f"**Usuario:** {usuario.mention}\n**Duración:** {duracion} minutos\n**Razón:** {razon}",
                color=0xffaa00
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            embed.set_footer(text=f"Silenciado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para silenciar a este usuario.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error timing out user: {e}")
            await interaction.response.send_message(
                "❌ Error al silenciar el usuario.",
                ephemeral=True
            )

    @app_commands.command(name="untimeout", description="Quitar timeout a un usuario")
    @app_commands.describe(usuario="Usuario al que quitar el timeout")
    @app_commands.default_permissions(moderate_members=True)
    async def untimeout(self, interaction: discord.Interaction, usuario: discord.Member):
        """Remove timeout from user"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            await usuario.timeout(None, reason=f"Timeout removido por: {interaction.user}")
            
            embed = discord.Embed(
                title="🔊 Timeout Removido",
                description=f"**Usuario:** {usuario.mention}",
                color=0x00ff00
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            embed.set_footer(text=f"Timeout removido por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para modificar el timeout de este usuario.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error removing timeout: {e}")
            await interaction.response.send_message(
                "❌ Error al quitar el timeout.",
                ephemeral=True
            )

    @app_commands.command(name="purge", description="Eliminar mensajes en masa")
    @app_commands.describe(
        cantidad="Cantidad de mensajes a eliminar (1-100)",
        usuario="Usuario específico (opcional)"
    )
    @app_commands.default_permissions(manage_messages=True)
    async def purge(self, interaction: discord.Interaction, cantidad: int, usuario: discord.Member = None):
        """Bulk delete messages"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if cantidad <= 0 or cantidad > 100:
            await interaction.response.send_message(
                "❌ La cantidad debe ser entre 1 y 100.",
                ephemeral=True
            )
            return

        try:
            await interaction.response.defer()
            
            def check_message(message):
                if usuario:
                    return message.author == usuario
                return True

            deleted = await interaction.channel.purge(limit=cantidad, check=check_message)
            
            embed = discord.Embed(
                title="🗑️ Mensajes Eliminados",
                description=f"**Eliminados:** {len(deleted)} mensajes",
                color=0x00ff00
            )
            
            if usuario:
                embed.add_field(name="Usuario", value=usuario.mention, inline=True)
            
            embed.set_footer(text=f"Eliminados por {interaction.user.display_name}")
            
            # Send confirmation and delete after 5 seconds
            msg = await interaction.followup.send(embed=embed)
            await asyncio.sleep(5)
            await msg.delete()
            
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.followup.send(
                "❌ No tengo permisos para eliminar mensajes.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error purging messages: {e}")
            await interaction.followup.send(
                "❌ Error al eliminar mensajes.",
                ephemeral=True
            )

    @app_commands.command(name="purge_embeds", description="Eliminar mensajes con embeds")
    @app_commands.describe(cantidad="Cantidad de mensajes a revisar (1-100)")
    @app_commands.default_permissions(manage_messages=True)
    async def purge_embeds(self, interaction: discord.Interaction, cantidad: int):
        """Delete messages with embeds"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if cantidad <= 0 or cantidad > 100:
            await interaction.response.send_message(
                "❌ La cantidad debe ser entre 1 y 100.",
                ephemeral=True
            )
            return

        try:
            await interaction.response.defer()
            
            def check_embed(message):
                return len(message.embeds) > 0

            deleted = await interaction.channel.purge(limit=cantidad, check=check_embed)
            
            embed = discord.Embed(
                title="🗑️ Mensajes con Embeds Eliminados",
                description=f"**Eliminados:** {len(deleted)} mensajes",
                color=0x00ff00
            )
            embed.set_footer(text=f"Eliminados por {interaction.user.display_name}")
            
            msg = await interaction.followup.send(embed=embed)
            await asyncio.sleep(5)
            await msg.delete()
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.followup.send(
                "❌ No tengo permisos para eliminar mensajes.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error purging embeds: {e}")
            await interaction.followup.send(
                "❌ Error al eliminar mensajes con embeds.",
                ephemeral=True
            )

    @app_commands.command(name="purge_images", description="Eliminar mensajes con imágenes")
    @app_commands.describe(cantidad="Cantidad de mensajes a revisar (1-100)")
    @app_commands.default_permissions(manage_messages=True)
    async def purge_images(self, interaction: discord.Interaction, cantidad: int):
        """Delete messages with images"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if cantidad <= 0 or cantidad > 100:
            await interaction.response.send_message(
                "❌ La cantidad debe ser entre 1 y 100.",
                ephemeral=True
            )
            return

        try:
            await interaction.response.defer()
            
            def check_image(message):
                return len(message.attachments) > 0

            deleted = await interaction.channel.purge(limit=cantidad, check=check_image)
            
            embed = discord.Embed(
                title="🗑️ Mensajes con Imágenes Eliminados",
                description=f"**Eliminados:** {len(deleted)} mensajes",
                color=0x00ff00
            )
            embed.set_footer(text=f"Eliminados por {interaction.user.display_name}")
            
            msg = await interaction.followup.send(embed=embed)
            await asyncio.sleep(5)
            await msg.delete()
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.followup.send(
                "❌ No tengo permisos para eliminar mensajes.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error purging images: {e}")
            await interaction.followup.send(
                "❌ Error al eliminar mensajes con imágenes.",
                ephemeral=True
            )

    @app_commands.command(name="purge_bots", description="Eliminar mensajes de bots")
    @app_commands.describe(cantidad="Cantidad de mensajes a revisar (1-100)")
    @app_commands.default_permissions(manage_messages=True)
    async def purge_bots(self, interaction: discord.Interaction, cantidad: int):
        """Delete bot messages"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if cantidad <= 0 or cantidad > 100:
            await interaction.response.send_message(
                "❌ La cantidad debe ser entre 1 y 100.",
                ephemeral=True
            )
            return

        try:
            await interaction.response.defer()
            
            def check_bot(message):
                return message.author.bot

            deleted = await interaction.channel.purge(limit=cantidad, check=check_bot)
            
            embed = discord.Embed(
                title="🗑️ Mensajes de Bots Eliminados",
                description=f"**Eliminados:** {len(deleted)} mensajes",
                color=0x00ff00
            )
            embed.set_footer(text=f"Eliminados por {interaction.user.display_name}")
            
            msg = await interaction.followup.send(embed=embed)
            await asyncio.sleep(5)
            await msg.delete()
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.followup.send(
                "❌ No tengo permisos para eliminar mensajes.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error purging bot messages: {e}")
            await interaction.followup.send(
                "❌ Error al eliminar mensajes de bots.",
                ephemeral=True
            )

    @app_commands.command(name="lock", description="Bloquear canal")
    @app_commands.describe(canal="Canal a bloquear (opcional, por defecto el actual)")
    @app_commands.default_permissions(manage_channels=True)
    async def lock(self, interaction: discord.Interaction, canal: discord.TextChannel = None):
        """Lock a channel"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        channel = canal or interaction.channel
        
        try:
            overwrite = channel.overwrites_for(interaction.guild.default_role)
            overwrite.send_messages = False
            await channel.set_permissions(interaction.guild.default_role, overwrite=overwrite)
            
            embed = discord.Embed(
                title="🔒 Canal Bloqueado",
                description=f"**Canal:** {channel.mention}",
                color=0xff0000
            )
            embed.set_footer(text=f"Bloqueado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para modificar este canal.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error locking channel: {e}")
            await interaction.response.send_message(
                "❌ Error al bloquear el canal.",
                ephemeral=True
            )

    @app_commands.command(name="unlock", description="Desbloquear canal")
    @app_commands.describe(canal="Canal a desbloquear (opcional, por defecto el actual)")
    @app_commands.default_permissions(manage_channels=True)
    async def unlock(self, interaction: discord.Interaction, canal: discord.TextChannel = None):
        """Unlock a channel"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        channel = canal or interaction.channel
        
        try:
            overwrite = channel.overwrites_for(interaction.guild.default_role)
            overwrite.send_messages = None
            await channel.set_permissions(interaction.guild.default_role, overwrite=overwrite)
            
            embed = discord.Embed(
                title="🔓 Canal Desbloqueado",
                description=f"**Canal:** {channel.mention}",
                color=0x00ff00
            )
            embed.set_footer(text=f"Desbloqueado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para modificar este canal.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error unlocking channel: {e}")
            await interaction.response.send_message(
                "❌ Error al desbloquear el canal.",
                ephemeral=True
            )

    @app_commands.command(name="warn", description="Advertir a un usuario")
    @app_commands.describe(
        usuario="Usuario a advertir",
        razon="Razón de la advertencia"
    )
    @app_commands.default_permissions(kick_members=True)
    async def warn(self, interaction: discord.Interaction, usuario: discord.Member, razon: str = "No especificada"):
        """Warn a user"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            embed = discord.Embed(
                title="⚠️ Usuario Advertido",
                description=f"**Usuario:** {usuario.mention}\n**Razón:** {razon}",
                color=0xffaa00
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            embed.set_footer(text=f"Advertido por {interaction.user.display_name}")
            
            # Try to send DM to user
            try:
                dm_embed = discord.Embed(
                    title="⚠️ Has sido advertido",
                    description=f"**Servidor:** {interaction.guild.name}\n**Razón:** {razon}",
                    color=0xffaa00
                )
                await usuario.send(embed=dm_embed)
            except:
                pass
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except Exception as e:
            logger.error(f"Error warning user: {e}")
            await interaction.response.send_message(
                "❌ Error al advertir el usuario.",
                ephemeral=True
            )

    @app_commands.command(name="slowmode", description="Configurar modo lento en canal")
    @app_commands.describe(
        segundos="Segundos de retraso (0-21600)",
        canal="Canal a configurar (opcional)"
    )
    @app_commands.default_permissions(manage_channels=True)
    async def slowmode(self, interaction: discord.Interaction, segundos: int, canal: discord.TextChannel = None):
        """Set slowmode on channel"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if segundos < 0 or segundos > 21600:
            await interaction.response.send_message(
                "❌ Los segundos deben estar entre 0 y 21600.",
                ephemeral=True
            )
            return

        channel = canal or interaction.channel
        
        try:
            await channel.edit(slowmode_delay=segundos)
            
            if segundos == 0:
                description = f"**Canal:** {channel.mention}\n**Estado:** Desactivado"
            else:
                description = f"**Canal:** {channel.mention}\n**Retraso:** {segundos} segundos"
            
            embed = discord.Embed(
                title="🐌 Modo Lento Configurado",
                description=description,
                color=0x0099ff
            )
            embed.set_footer(text=f"Configurado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para modificar este canal.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error setting slowmode: {e}")
            await interaction.response.send_message(
                "❌ Error al configurar modo lento.",
                ephemeral=True
            )

    @app_commands.command(name="unban", description="Desbanear un usuario por ID")
    @app_commands.describe(
        user_id="ID del usuario a desbanear",
        razon="Razón del desbaneo"
    )
    @app_commands.default_permissions(ban_members=True)
    async def unban(self, interaction: discord.Interaction, user_id: str, razon: str = "No especificada"):
        """Unban a user"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            user_id_int = int(user_id)
            user = await self.bot.fetch_user(user_id_int)
            await interaction.guild.unban(user, reason=f"{razon} | Por: {interaction.user}")
            
            embed = discord.Embed(
                title="✅ Usuario Desbaneado",
                description=f"**Usuario:** {user.mention}\n**Razón:** {razon}",
                color=0x00ff00
            )
            embed.set_thumbnail(url=user.display_avatar.url)
            embed.set_footer(text=f"Desbaneado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except ValueError:
            await interaction.response.send_message(
                "❌ ID de usuario inválido.",
                ephemeral=True
            )
        except discord.NotFound:
            await interaction.response.send_message(
                "❌ Usuario no encontrado o no está baneado.",
                ephemeral=True
            )
        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para desbanear usuarios.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error unbanning user: {e}")
            await interaction.response.send_message(
                "❌ Error al desbanear el usuario.",
                ephemeral=True
            )

    @app_commands.command(name="role_add", description="Dar rol a un usuario")
    @app_commands.describe(
        usuario="Usuario al que dar el rol",
        rol="Rol a dar",
        razon="Razón para dar el rol"
    )
    @app_commands.default_permissions(manage_roles=True)
    async def role_add(self, interaction: discord.Interaction, usuario: discord.Member, rol: discord.Role, razon: str = "No especificada"):
        """Add role to user"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        # Check role hierarchy
        if rol >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
            await interaction.response.send_message(
                "❌ No puedes dar un rol igual o superior al tuyo.",
                ephemeral=True
            )
            return

        if rol in usuario.roles:
            await interaction.response.send_message(
                "❌ El usuario ya tiene este rol.",
                ephemeral=True
            )
            return

        try:
            await usuario.add_roles(rol, reason=f"{razon} | Por: {interaction.user}")
            
            embed = discord.Embed(
                title="✅ Rol Asignado",
                description=f"**Usuario:** {usuario.mention}\n**Rol:** {rol.mention}\n**Razón:** {razon}",
                color=rol.color
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            embed.set_footer(text=f"Rol dado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para dar este rol.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error adding role: {e}")
            await interaction.response.send_message(
                "❌ Error al dar el rol.",
                ephemeral=True
            )

    @app_commands.command(name="role_remove", description="Quitar rol a un usuario")
    @app_commands.describe(
        usuario="Usuario al que quitar el rol",
        rol="Rol a quitar",
        razon="Razón para quitar el rol"
    )
    @app_commands.default_permissions(manage_roles=True)
    async def role_remove(self, interaction: discord.Interaction, usuario: discord.Member, rol: discord.Role, razon: str = "No especificada"):
        """Remove role from user"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        # Check role hierarchy
        if rol >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
            await interaction.response.send_message(
                "❌ No puedes quitar un rol igual o superior al tuyo.",
                ephemeral=True
            )
            return

        if rol not in usuario.roles:
            await interaction.response.send_message(
                "❌ El usuario no tiene este rol.",
                ephemeral=True
            )
            return

        try:
            await usuario.remove_roles(rol, reason=f"{razon} | Por: {interaction.user}")
            
            embed = discord.Embed(
                title="❌ Rol Removido",
                description=f"**Usuario:** {usuario.mention}\n**Rol:** {rol.mention}\n**Razón:** {razon}",
                color=0xff9900
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            embed.set_footer(text=f"Rol quitado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para quitar este rol.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error removing role: {e}")
            await interaction.response.send_message(
                "❌ Error al quitar el rol.",
                ephemeral=True
            )

    @app_commands.command(name="nickname", description="Cambiar nickname de un usuario")
    @app_commands.describe(
        usuario="Usuario a cambiar nickname",
        nickname="Nuevo nickname (vacío para quitar)"
    )
    @app_commands.default_permissions(manage_nicknames=True)
    async def nickname(self, interaction: discord.Interaction, usuario: discord.Member, nickname: str = None):
        """Change user nickname"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            old_nick = usuario.display_name
            await usuario.edit(nick=nickname, reason=f"Nickname cambiado por {interaction.user}")
            
            new_nick = nickname if nickname else usuario.name
            
            embed = discord.Embed(
                title="✏️ Nickname Cambiado",
                description=f"**Usuario:** {usuario.mention}\n**Anterior:** {old_nick}\n**Nuevo:** {new_nick}",
                color=0x0099ff
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            embed.set_footer(text=f"Cambiado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para cambiar nicknames.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error changing nickname: {e}")
            await interaction.response.send_message(
                "❌ Error al cambiar el nickname.",
                ephemeral=True
            )

    @app_commands.command(name="voice_kick", description="Expulsar usuario de canal de voz")
    @app_commands.describe(usuario="Usuario a expulsar de voz")
    @app_commands.default_permissions(move_members=True)
    async def voice_kick(self, interaction: discord.Interaction, usuario: discord.Member):
        """Kick user from voice channel"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if not usuario.voice:
            await interaction.response.send_message(
                "❌ El usuario no está en un canal de voz.",
                ephemeral=True
            )
            return

        try:
            voice_channel = usuario.voice.channel.name
            await usuario.move_to(None, reason=f"Expulsado de voz por {interaction.user}")
            
            embed = discord.Embed(
                title="🔊 Usuario Expulsado de Voz",
                description=f"**Usuario:** {usuario.mention}\n**Canal:** {voice_channel}",
                color=0xff9900
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            embed.set_footer(text=f"Expulsado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para mover usuarios en canales de voz.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error kicking from voice: {e}")
            await interaction.response.send_message(
                "❌ Error al expulsar de voz.",
                ephemeral=True
            )

    @app_commands.command(name="voice_mute", description="Silenciar usuario en canal de voz")
    @app_commands.describe(usuario="Usuario a silenciar en voz")
    @app_commands.default_permissions(mute_members=True)
    async def voice_mute(self, interaction: discord.Interaction, usuario: discord.Member):
        """Mute user in voice channel"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if not usuario.voice:
            await interaction.response.send_message(
                "❌ El usuario no está en un canal de voz.",
                ephemeral=True
            )
            return

        try:
            await usuario.edit(mute=True, reason=f"Silenciado en voz por {interaction.user}")
            
            embed = discord.Embed(
                title="🔇 Usuario Silenciado en Voz",
                description=f"**Usuario:** {usuario.mention}",
                color=0xff0000
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            embed.set_footer(text=f"Silenciado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para silenciar usuarios en voz.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error voice muting user: {e}")
            await interaction.response.send_message(
                "❌ Error al silenciar en voz.",
                ephemeral=True
            )

    @app_commands.command(name="voice_unmute", description="Quitar silencio de usuario en voz")
    @app_commands.describe(usuario="Usuario a des-silenciar en voz")
    @app_commands.default_permissions(mute_members=True)
    async def voice_unmute(self, interaction: discord.Interaction, usuario: discord.Member):
        """Unmute user in voice channel"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if not usuario.voice:
            await interaction.response.send_message(
                "❌ El usuario no está en un canal de voz.",
                ephemeral=True
            )
            return

        try:
            await usuario.edit(mute=False, reason=f"Silencio quitado por {interaction.user}")
            
            embed = discord.Embed(
                title="🔊 Silencio de Voz Removido",
                description=f"**Usuario:** {usuario.mention}",
                color=0x00ff00
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            embed.set_footer(text=f"Des-silenciado por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para des-silenciar usuarios en voz.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error voice unmuting user: {e}")
            await interaction.response.send_message(
                "❌ Error al quitar silencio de voz.",
                ephemeral=True
            )

    @app_commands.command(name="voice_deafen", description="Ensordecer usuario en canal de voz")
    @app_commands.describe(usuario="Usuario a ensordecer en voz")
    @app_commands.default_permissions(deafen_members=True)
    async def voice_deafen(self, interaction: discord.Interaction, usuario: discord.Member):
        """Deafen user in voice channel"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if not usuario.voice:
            await interaction.response.send_message(
                "❌ El usuario no está en un canal de voz.",
                ephemeral=True
            )
            return

        try:
            await usuario.edit(deafen=True, reason=f"Ensordecido por {interaction.user}")
            
            embed = discord.Embed(
                title="🔇 Usuario Ensordecido",
                description=f"**Usuario:** {usuario.mention}",
                color=0xff0000
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            embed.set_footer(text=f"Ensordecido por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para ensordecer usuarios.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error deafening user: {e}")
            await interaction.response.send_message(
                "❌ Error al ensordecer usuario.",
                ephemeral=True
            )

    @app_commands.command(name="voice_undeafen", description="Quitar ensordecimiento de usuario")
    @app_commands.describe(usuario="Usuario a des-ensordecer")
    @app_commands.default_permissions(deafen_members=True)
    async def voice_undeafen(self, interaction: discord.Interaction, usuario: discord.Member):
        """Undeafen user in voice channel"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if not usuario.voice:
            await interaction.response.send_message(
                "❌ El usuario no está en un canal de voz.",
                ephemeral=True
            )
            return

        try:
            await usuario.edit(deafen=False, reason=f"Des-ensordecido por {interaction.user}")
            
            embed = discord.Embed(
                title="🔊 Ensordecimiento Removido",
                description=f"**Usuario:** {usuario.mention}",
                color=0x00ff00
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            embed.set_footer(text=f"Des-ensordecido por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para des-ensordecer usuarios.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error undeafening user: {e}")
            await interaction.response.send_message(
                "❌ Error al quitar ensordecimiento.",
                ephemeral=True
            )

    @app_commands.command(name="banlist", description="Ver lista de usuarios baneados")
    async def banlist(self, interaction: discord.Interaction):
        """Show ban list"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        try:
            bans = [ban async for ban in interaction.guild.bans(limit=100)]
            
            if not bans:
                embed = discord.Embed(
                    title="📋 Lista de Baneados",
                    description="No hay usuarios baneados en este servidor.",
                    color=0x00ff00
                )
                await interaction.response.send_message(embed=embed)
                return
            
            embed = discord.Embed(
                title="📋 Lista de Baneados",
                description=f"**Total de baneados:** {len(bans)}",
                color=0xff0000
            )
            
            ban_list = []
            for i, ban in enumerate(bans[:10]):  # Show only first 10
                reason = ban.reason or "No especificada"
                ban_list.append(f"{i+1}. **{ban.user}** (`{ban.user.id}`)\n   Razón: {reason}")
            
            embed.add_field(
                name="Usuarios Baneados (Mostrando primeros 10):",
                value="\n\n".join(ban_list),
                inline=False
            )
            
            if len(bans) > 10:
                embed.set_footer(text=f"Y {len(bans) - 10} más...")
            
            await interaction.response.send_message(embed=embed)
            await increment_command_usage(interaction.user.id)

        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ No tengo permisos para ver la lista de baneados.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error showing ban list: {e}")
            await interaction.response.send_message(
                "❌ Error al cargar lista de baneados.",
                ephemeral=True
            )

    @app_commands.command(name="clean_bots", description="Expulsar todos los bots del servidor")
    @app_commands.describe(confirmar="Escribe 'CONFIRMAR' para proceder")
    @app_commands.default_permissions(kick_members=True)
    async def clean_bots(self, interaction: discord.Interaction, confirmar: str):
        """Kick all bots from server"""
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium. Contacta un admin para obtener una key.",
                ephemeral=True
            )
            return

        if confirmar.upper() != "CONFIRMAR":
            await interaction.response.send_message(
                "❌ Debes escribir 'CONFIRMAR' para proceder con la limpieza de bots.",
                ephemeral=True
            )
            return

        try:
            await interaction.response.defer()
            
            kicked_count = 0
            failed_count = 0
            
            for member in interaction.guild.members:
                if member.bot and member != self.bot.user:  # Don't kick ourselves
                    try:
                        await member.kick(reason=f"Limpieza de bots por {interaction.user}")
                        kicked_count += 1
                        await asyncio.sleep(0.5)  # Rate limit protection
                    except:
                        failed_count += 1
            
            embed = discord.Embed(
                title="🤖 Limpieza de Bots Completada",
                description=f"**Bots expulsados:** {kicked_count}\n**Fallidos:** {failed_count}",
                color=0x00ff00
            )
            embed.set_footer(text=f"Ejecutado por {interaction.user.display_name}")
            
            await interaction.followup.send(embed=embed)
            await increment_command_usage(interaction.user.id)

        except Exception as e:
            logger.error(f"Error cleaning bots: {e}")
            await interaction.followup.send(
                "❌ Error al limpiar bots.",
                ephemeral=True
            )
