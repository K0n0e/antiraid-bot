import discord
from discord import app_commands
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)

class HelpCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="ayuda", description="Menú de ayuda con todos los comandos")
    async def ayuda(self, interaction: discord.Interaction):
        """Help menu with all commands"""
        
        # Main menu embed
        embed = discord.Embed(
            title="🆘 MENÚ DE AYUDA - CUARTETO SQUAD BOT",
            description="**Bot Premium Antiraid en Español**\n\nSelecciona una categoría para ver los comandos disponibles:",
            color=0x4f46e5
        )
        
        embed.add_field(
            name="🛡️ AntiRaid",
            value="Comandos de protección contra raids",
            inline=True
        )
        
        embed.add_field(
            name="🔨 Moderación", 
            value="Comandos de moderación del servidor",
            inline=True
        )
        
        embed.add_field(
            name="⚙️ Administración",
            value="Gestión del bot y keys premium",
            inline=True
        )
        
        embed.add_field(
            name="👤 Perfil",
            value="Ver información de usuarios",
            inline=True
        )
        
        embed.add_field(
            name="💎 Premium",
            value="Sistema de keys y acceso premium", 
            inline=True
        )
        
        embed.add_field(
            name="📊 Información",
            value="Estadísticas y estado del bot",
            inline=True
        )
        
        embed.set_footer(text="💎 Bot Premium • Solo usuarios con key pueden usar los comandos")
        embed.set_thumbnail(url=interaction.client.user.display_avatar.url)
        
        # Create view with buttons
        view = HelpView()
        
        await interaction.response.send_message(embed=embed, view=view)

class HelpView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)
    
    @discord.ui.button(label="🛡️ AntiRaid", style=discord.ButtonStyle.primary)
    async def antiraid_help(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="🛡️ COMANDOS ANTIRAID",
            description="Protección avanzada contra raids y ataques",
            color=0xef4444
        )
        
        embed.add_field(
            name="**Protección Básica**",
            value="```\n/antiraid - Configurar protección básica\n/raid_mode - Modo raid (5 niveles)\n/verify_protection - Analizar seguridad\n/emergency_lock - Bloqueo de emergencia\n/emergency_unlock - Desbloquear emergencia```",
            inline=False
        )
        
        embed.add_field(
            name="**Control de Servidor**",
            value="```\n/lockdown - Bloquear servidor completo\n/unlockdown - Desbloquear servidor\n/nuke - Recrear canales\n/massban - Banear múltiples usuarios\n/clean_bots - Expulsar todos los bots```",
            inline=False
        )
        
        embed.add_field(
            name="**Filtros Automáticos**",
            value="```\n/anti_invite - Anti enlaces de Discord\n/anti_spam - Anti spam avanzado\n/account_age_limit - Filtrar cuentas nuevas\n/auto_dehoist - Quitar caracteres raros\n/captcha_setup - Sistema captcha```",
            inline=False
        )
        
        embed.add_field(
            name="**Whitelist y Backups**",
            value="```\n/whitelist_add - Agregar a whitelist\n/whitelist_remove - Quitar de whitelist\n/backup_channels - Backup de canales\n/server_backup - Backup completo del servidor```",
            inline=False
        )
        
        await interaction.response.edit_message(embed=embed, view=BackButtonView())
    
    @discord.ui.button(label="🔨 Moderación", style=discord.ButtonStyle.secondary)
    async def moderation_help(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="🔨 COMANDOS MODERACIÓN",
            description="Control y moderación del servidor",
            color=0xf97316
        )
        
        embed.add_field(
            name="**Sanciones Básicas**",
            value="```\n/ban - Banear usuario\n/kick - Expulsar usuario\n/unban - Desbanear usuario\n/timeout - Timeout temporal\n/untimeout - Quitar timeout\n/warn - Advertir usuario```",
            inline=False
        )
        
        embed.add_field(
            name="**Limpieza de Mensajes**",
            value="```\n/purge - Borrar mensajes (cantidad)\n/purge_embeds - Borrar embeds\n/purge_images - Borrar imágenes\n/purge_bots - Borrar mensajes de bots\n/purge_user - Borrar mensajes de usuario```",
            inline=False
        )
        
        embed.add_field(
            name="**Gestión de Roles**",
            value="```\n/role_add - Dar rol a usuario\n/role_remove - Quitar rol a usuario\n/role_all - Dar rol a todos\n/role_humans - Dar rol a humanos\n/role_bots - Dar rol a bots```",
            inline=False
        )
        
        embed.add_field(
            name="**Control de Canales**",
            value="```\n/lock - Bloquear canal\n/unlock - Desbloquear canal\n/slowmode - Modo lento\n/nickname - Cambiar nickname\n/banlist - Ver lista de baneados```",
            inline=False
        )
        
        embed.add_field(
            name="**Control de Voz**",
            value="```\n/voice_kick - Expulsar de canal de voz\n/voice_mute - Mutear en voz\n/voice_deafen - Ensordecer usuario\n/voice_move_all - Mover todos a canal```",
            inline=False
        )
        
        await interaction.response.edit_message(embed=embed, view=BackButtonView())
    
    @discord.ui.button(label="⚙️ Admin", style=discord.ButtonStyle.success)
    async def admin_help(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="⚙️ COMANDOS ADMINISTRACIÓN",
            description="Gestión del bot y administración",
            color=0x10b981
        )
        
        embed.add_field(
            name="**Gestión de Keys**",
            value="```\n/generar - Generar key premium\n/sorteo_keys - Sortear keys premium\n/use_key - Activar key premium```",
            inline=False
        )
        
        embed.add_field(
            name="**Gestión de Staff**",
            value="```\n/dar_admin - Dar permisos de admin (solo fundador)\n/stats - Estadísticas del bot```",
            inline=False
        )
        
        embed.add_field(
            name="**Blacklist Global**",
            value="```\n/blacklist_add - Agregar a blacklist global\n/blacklist_remove - Quitar de blacklist\n/blacklist_check - Verificar si está en blacklist```",
            inline=False
        )
        
        embed.add_field(
            name="**Permisos de Comandos**",
            value="**🔐 Solo Fundador:** dar_admin\n**👑 Fundador + Admins:** generar, sorteo_keys, blacklist, stats\n**💎 Premium:** Resto de comandos",
            inline=False
        )
        
        await interaction.response.edit_message(embed=embed, view=BackButtonView())
    
    @discord.ui.button(label="💎 Premium", style=discord.ButtonStyle.primary)
    async def premium_help(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(
            title="💎 SISTEMA PREMIUM",
            description="Información sobre el acceso premium",
            color=0xffd700
        )
        
        embed.add_field(
            name="**¿Qué es Premium?**",
            value="Este bot es **100% premium**. Solo usuarios con keys activas pueden usar los comandos.",
            inline=False
        )
        
        embed.add_field(
            name="**Cómo obtener Premium**",
            value="• Participar en sorteos con `/sorteo_keys`\n• Contactar al fundador k0n0e_\n• Eventos especiales del servidor",
            inline=False
        )
        
        embed.add_field(
            name="**Activar tu Key**",
            value="```\n/use_key TU-KEY-AQUI\n```",
            inline=False
        )
        
        embed.add_field(
            name="**Tipos de Keys**",
            value="**⏰ Temporales:** 1d, 7d, 30d, etc.\n**♾️ Permanentes:** lifetime (sin expiración)",
            inline=False
        )
        
        embed.add_field(
            name="**Ver tu Estado**",
            value="Usa `/perfil` para verificar tu estado premium y fecha de expiración.",
            inline=False
        )
        
        await interaction.response.edit_message(embed=embed, view=BackButtonView())

class BackButtonView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=300)
    
    @discord.ui.button(label="🏠 Volver al Menú", style=discord.ButtonStyle.secondary)
    async def back_to_menu(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Recreate main menu embed
        embed = discord.Embed(
            title="🆘 MENÚ DE AYUDA - CUARTETO SQUAD BOT",
            description="**Bot Premium Antiraid en Español**\n\nSelecciona una categoría para ver los comandos disponibles:",
            color=0x4f46e5
        )
        
        embed.add_field(name="🛡️ AntiRaid", value="Comandos de protección contra raids", inline=True)
        embed.add_field(name="🔨 Moderación", value="Comandos de moderación del servidor", inline=True)
        embed.add_field(name="⚙️ Administración", value="Gestión del bot y keys premium", inline=True)
        embed.add_field(name="👤 Perfil", value="Ver información de usuarios", inline=True)
        embed.add_field(name="💎 Premium", value="Sistema de keys y acceso premium", inline=True)
        embed.add_field(name="📊 Información", value="Estadísticas y estado del bot", inline=True)
        
        embed.set_footer(text="💎 Bot Premium • Solo usuarios con key pueden usar los comandos")
        embed.set_thumbnail(url=interaction.client.user.display_avatar.url)
        
        view = HelpView()
        await interaction.response.edit_message(embed=embed, view=view)

async def setup(bot):
    await bot.add_cog(HelpCommands(bot))