import discord
from discord.ext import commands
from discord import app_commands
import secrets
import string
from datetime import datetime, timedelta
import logging

from database import (
    create_premium_key, add_bot_admin, is_bot_admin, 
    add_to_blacklist, remove_from_blacklist
)
from utils.permissions import is_founder, check_premium
from config import FOUNDER_ID

logger = logging.getLogger(__name__)

class AdminCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def generate_key_code(self, length=16):
        """Generate a random key code"""
        characters = string.ascii_letters + string.digits
        return ''.join(secrets.choice(characters) for _ in range(length))

    @app_commands.command(name="generar", description="Generar key premium (Solo admins y fundador)")
    @app_commands.describe(
        duracion="Duración de la key (ej: 5d, 30d, lifetime)",
        cantidad="Cantidad de keys a generar (default: 1)"
    )
    async def generar_key(self, interaction: discord.Interaction, duracion: str, cantidad: int = 1):
        """Generate premium keys"""
        # Check permissions
        if not (is_founder(interaction.user.id) or await is_bot_admin(interaction.user.id)):
            await interaction.response.send_message(
                "❌ Solo el fundador y los admins pueden usar este comando.",
                ephemeral=True
            )
            return

        # Parse duration
        expires_at = None
        if duracion.lower() != "lifetime":
            try:
                if duracion.endswith('d'):
                    days = int(duracion[:-1])
                    expires_at = (datetime.now() + timedelta(days=days)).isoformat()
                elif duracion.endswith('h'):
                    hours = int(duracion[:-1])
                    expires_at = (datetime.now() + timedelta(hours=hours)).isoformat()
                else:
                    await interaction.response.send_message(
                        "❌ Formato de duración inválido. Usa: `5d` (días), `24h` (horas), o `lifetime`",
                        ephemeral=True
                    )
                    return
            except ValueError:
                await interaction.response.send_message(
                    "❌ Formato de duración inválido. Usa números seguidos de 'd' o 'h'",
                    ephemeral=True
                )
                return

        # Limit quantity
        if cantidad > 10:
            await interaction.response.send_message(
                "❌ No puedes generar más de 10 keys a la vez.",
                ephemeral=True
            )
            return

        try:
            # Generate keys
            keys = []
            for _ in range(cantidad):
                key_code = self.generate_key_code()
                await create_premium_key(key_code, expires_at, interaction.user.id)
                keys.append(key_code)

            # Create response
            duration_text = duracion if duracion.lower() == "lifetime" else f"{duracion}"
            embed = discord.Embed(
                title="🔑 Keys Premium Generadas",
                description=f"**Duración:** {duration_text}\n**Cantidad:** {cantidad}",
                color=0x00ff00
            )

            key_list = "\n".join([f"`{key}`" for key in keys])
            embed.add_field(
                name="Keys Generadas:",
                value=key_list,
                inline=False
            )

            embed.set_footer(text=f"Generadas por {interaction.user.display_name}")

            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"Generated {cantidad} premium keys by {interaction.user} ({interaction.user.id})")

        except Exception as e:
            logger.error(f"Error generating keys: {e}")
            await interaction.response.send_message(
                "❌ Error al generar las keys. Inténtalo de nuevo.",
                ephemeral=True
            )

    @app_commands.command(name="dar_admin", description="Dar permisos de admin a un usuario (Solo fundador)")
    @app_commands.describe(usuario="Usuario al que dar permisos de admin")
    async def dar_admin(self, interaction: discord.Interaction, usuario: discord.Member):
        """Give admin permissions to a user"""
        if not is_founder(interaction.user.id):
            await interaction.response.send_message(
                "❌ Solo el fundador puede usar este comando.",
                ephemeral=True
            )
            return

        try:
            await add_bot_admin(usuario.id, interaction.user.id)
            
            embed = discord.Embed(
                title="👑 Admin Asignado",
                description=f"{usuario.mention} ahora tiene permisos de admin del bot.",
                color=0xffd700
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            
            await interaction.response.send_message(embed=embed)
            logger.info(f"Admin permissions granted to {usuario} ({usuario.id}) by founder")

        except Exception as e:
            logger.error(f"Error giving admin permissions: {e}")
            await interaction.response.send_message(
                "❌ Error al asignar permisos de admin.",
                ephemeral=True
            )

    @app_commands.command(name="blacklist_add", description="Añadir usuario a blacklist global")
    @app_commands.describe(
        usuario="Usuario a añadir a la blacklist",
        razon="Razón del blacklist"
    )
    async def blacklist_add(self, interaction: discord.Interaction, usuario: discord.Member, razon: str):
        """Add user to global blacklist"""
        if not (is_founder(interaction.user.id) or await is_bot_admin(interaction.user.id)):
            await interaction.response.send_message(
                "❌ Solo el fundador y los admins pueden usar este comando.",
                ephemeral=True
            )
            return

        # Don't allow blacklisting founder or admins
        if is_founder(usuario.id) or await is_bot_admin(usuario.id):
            await interaction.response.send_message(
                "❌ No puedes añadir al fundador o admins a la blacklist.",
                ephemeral=True
            )
            return

        try:
            await add_to_blacklist(usuario.id, razon, interaction.user.id, usuario.bot)
            
            embed = discord.Embed(
                title="🚫 Usuario Añadido a Blacklist",
                description=f"**Usuario:** {usuario.mention}\n**Razón:** {razon}",
                color=0xff0000
            )
            embed.set_thumbnail(url=usuario.display_avatar.url)
            embed.set_footer(text=f"Añadido por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            
            # Try to ban from current guild
            try:
                await usuario.ban(reason=f"Global blacklist: {razon}")
                await interaction.followup.send(f"✅ {usuario.mention} ha sido baneado de este servidor.", ephemeral=True)
            except discord.Forbidden:
                await interaction.followup.send("⚠️ No se pudo banear del servidor actual - permisos insuficientes.", ephemeral=True)
            
            logger.info(f"Added {usuario} ({usuario.id}) to blacklist by {interaction.user}")

        except Exception as e:
            logger.error(f"Error adding to blacklist: {e}")
            await interaction.response.send_message(
                "❌ Error al añadir a la blacklist.",
                ephemeral=True
            )

    @app_commands.command(name="blacklist_remove", description="Quitar usuario de blacklist global")
    @app_commands.describe(user_id="ID del usuario a quitar de la blacklist")
    async def blacklist_remove(self, interaction: discord.Interaction, user_id: str):
        """Remove user from global blacklist"""
        if not (is_founder(interaction.user.id) or await is_bot_admin(interaction.user.id)):
            await interaction.response.send_message(
                "❌ Solo el fundador y los admins pueden usar este comando.",
                ephemeral=True
            )
            return

        try:
            user_id_int = int(user_id)
            await remove_from_blacklist(user_id_int)
            
            embed = discord.Embed(
                title="✅ Usuario Removido de Blacklist",
                description=f"**Usuario ID:** {user_id}",
                color=0x00ff00
            )
            embed.set_footer(text=f"Removido por {interaction.user.display_name}")
            
            await interaction.response.send_message(embed=embed)
            logger.info(f"Removed user {user_id} from blacklist by {interaction.user}")

        except ValueError:
            await interaction.response.send_message(
                "❌ ID de usuario inválido.",
                ephemeral=True
            )
        except Exception as e:
            logger.error(f"Error removing from blacklist: {e}")
            await interaction.response.send_message(
                "❌ Error al quitar de la blacklist.",
                ephemeral=True
            )

    @app_commands.command(name="sorteo_keys", description="Realizar sorteo de keys premium")
    @app_commands.describe(
        cantidad="Cantidad de keys a sortear",
        duracion="Duración de las keys (ej: 30d, lifetime)",
        participantes="Número de ganadores"
    )
    async def sorteo_keys(self, interaction: discord.Interaction, cantidad: int, duracion: str, participantes: int = 1):
        """Raffle premium keys"""
        if not (is_founder(interaction.user.id) or await is_bot_admin(interaction.user.id)):
            await interaction.response.send_message(
                "❌ Solo el fundador y los admins pueden usar este comando.",
                ephemeral=True
            )
            return

        if cantidad < 1 or cantidad > 20:
            await interaction.response.send_message(
                "❌ La cantidad debe ser entre 1 y 20 keys.",
                ephemeral=True
            )
            return

        if participantes < 1 or participantes > cantidad:
            await interaction.response.send_message(
                "❌ El número de participantes debe ser entre 1 y la cantidad de keys.",
                ephemeral=True
            )
            return

        # Parse duration
        expires_at = None
        if duracion.lower() != "lifetime":
            try:
                if duracion.endswith('d'):
                    days = int(duracion[:-1])
                    expires_at = (datetime.now() + timedelta(days=days)).isoformat()
                elif duracion.endswith('h'):
                    hours = int(duracion[:-1])
                    expires_at = (datetime.now() + timedelta(hours=hours)).isoformat()
                else:
                    await interaction.response.send_message(
                        "❌ Formato de duración inválido. Usa: `5d` (días), `24h` (horas), o `lifetime`",
                        ephemeral=True
                    )
                    return
            except ValueError:
                await interaction.response.send_message(
                    "❌ Formato de duración inválido.",
                    ephemeral=True
                )
                return

        try:
            # Generate keys first
            keys = []
            for _ in range(cantidad):
                key_code = self.generate_key_code()
                await create_premium_key(key_code, expires_at, interaction.user.id)
                keys.append(key_code)

            # Create raffle embed
            duration_text = duracion if duracion.lower() == "lifetime" else f"{duracion}"
            
            embed = discord.Embed(
                title="🎉 ¡SORTEO DE KEYS PREMIUM!",
                description=f"**Keys disponibles:** {cantidad}\n**Duración:** {duration_text}\n**Ganadores:** {participantes}",
                color=0xffd700
            )
            
            embed.add_field(
                name="📋 Cómo participar:",
                value="Reacciona con 🎟️ para participar en el sorteo!",
                inline=False
            )
            
            embed.add_field(
                name="⏰ Estado:",
                value="**ACTIVO** - El sorteo terminará en 3 minutos",
                inline=True
            )
            
            embed.set_footer(text=f"Sorteo creado por {interaction.user.display_name}")
            embed.timestamp = datetime.now()

            await interaction.response.send_message(embed=embed)
            message = await interaction.original_response()
            await message.add_reaction("🎟️")

            # Wait 3 minutes for participants
            import asyncio
            await asyncio.sleep(180)

            # Get participants
            message = await message.fetch()
            participants = []
            for reaction in message.reactions:
                if str(reaction.emoji) == "🎟️":
                    users = [user async for user in reaction.users()]
                    participants = [user for user in users if not user.bot]
                    break

            if len(participants) < participantes:
                embed.color = 0xff9900
                embed.clear_fields()
                embed.add_field(
                    name="⚠️ Sorteo Cancelado",
                    value=f"No hay suficientes participantes ({len(participants)} de {participantes} necesarios)",
                    inline=False
                )
                await message.edit(embed=embed)
                return

            # Select random winners
            import random
            winners = random.sample(participants, min(participantes, len(participants)))
            
            # Remove duplicates if any
            winners = list(set(winners))[:participantes]

            # Send keys to winners
            embed.color = 0x00ff00
            embed.clear_fields()
            
            winner_mentions = [winner.mention for winner in winners]
            embed.add_field(
                name="🎊 ¡GANADORES!",
                value="\n".join(winner_mentions),
                inline=False
            )
            
            embed.add_field(
                name="📨 Entrega de Keys",
                value="Las keys han sido enviadas por DM a los ganadores.",
                inline=False
            )

            await message.edit(embed=embed)

            # Send keys via DM
            for i, winner in enumerate(winners):
                try:
                    key_embed = discord.Embed(
                        title="🎉 ¡Has ganado una key premium!",
                        description=f"**Tu key:** `{keys[i]}`\n**Duración:** {duration_text}",
                        color=0xffd700
                    )
                    key_embed.add_field(
                        name="💎 Activar key:",
                        value="Usa `/use_key` seguido de tu key para activar tu premium.",
                        inline=False
                    )
                    await winner.send(embed=key_embed)
                except:
                    # If DM fails, try to mention in channel
                    try:
                        await interaction.followup.send(
                            f"{winner.mention} Tu key premium: `{keys[i]}` (no pude enviarte DM)",
                            ephemeral=True
                        )
                    except:
                        pass

            logger.info(f"Key raffle completed by {interaction.user} - {len(winners)} winners")

        except Exception as e:
            logger.error(f"Error in key raffle: {e}")
            await interaction.followup.send(
                "❌ Error al realizar el sorteo.",
                ephemeral=True
            )

    @app_commands.command(name="canal_anuncios", description="Configurar canal de anuncios globales")
    @app_commands.describe(canal="Canal donde se mostrarán los anuncios globales")
    async def canal_anuncios(self, interaction: discord.Interaction, canal: discord.TextChannel):
        """Set global announcements channel"""
        from utils.permissions import check_premium
        if not await check_premium(interaction.user.id):
            await interaction.response.send_message(
                "❌ Este comando requiere premium.", ephemeral=True
            )
            return
            
        if not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message(
                "❌ Solo administradores del servidor pueden usar este comando.", ephemeral=True
            )
            return

        try:
            from database import get_db_connection
            conn = await get_db_connection()
            await conn.execute(
                "INSERT OR REPLACE INTO guild_settings (guild_id, announcements_channel, created_at) VALUES (?, ?, ?)",
                (interaction.guild.id, canal.id, datetime.now().isoformat())
            )
            await conn.commit()
            await conn.close()
            
            embed = discord.Embed(
                title="📢 Canal de Anuncios Configurado",
                description=f"Los anuncios globales del fundador aparecerán en {canal.mention}",
                color=0x00ff00
            )
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            logger.error(f"Error setting announcements channel: {e}")
            await interaction.response.send_message(
                "❌ Error al configurar canal de anuncios.", ephemeral=True
            )

    @app_commands.command(name="stats", description="Ver estadísticas del bot")
    async def stats(self, interaction: discord.Interaction):
        """Show bot statistics"""
        if not (is_founder(interaction.user.id) or await is_bot_admin(interaction.user.id)):
            await interaction.response.send_message(
                "❌ Solo el fundador y los admins pueden usar este comando.",
                ephemeral=True
            )
            return

        try:
            embed = discord.Embed(
                title="📊 Estadísticas del Bot",
                color=0x0099ff
            )
            
            embed.add_field(
                name="🏠 Servidores",
                value=str(len(self.bot.guilds)),
                inline=True
            )
            
            total_members = sum(guild.member_count for guild in self.bot.guilds)
            embed.add_field(
                name="👥 Usuarios Totales",
                value=str(total_members),
                inline=True
            )
            
            embed.add_field(
                name="📡 Latencia",
                value=f"{round(self.bot.latency * 1000)}ms",
                inline=True
            )
            
            embed.set_footer(text=f"Bot ID: {self.bot.user.id}")
            
            await interaction.response.send_message(embed=embed, ephemeral=True)

        except Exception as e:
            logger.error(f"Error showing stats: {e}")
            await interaction.response.send_message(
                "❌ Error al obtener estadísticas.",
                ephemeral=True
            )
