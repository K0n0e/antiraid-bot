# Bot Configuration
FOUNDER_ID = 1308470371724427297
FOUNDER_NAME = "k0n0e_"

# Database Configuration
DATABASE_FILE = "antiraid_bot.db"

# Bot Settings
DEFAULT_PREFIX = "!"
MAX_PREMIUM_KEYS_PER_GENERATION = 10
MAX_MASSBAN_USERS = 20
RAID_DETECTION_DEFAULT_THRESHOLD = 5

# Logging Configuration
LOG_LEVEL = "INFO"
LOG_FILE = "bot.log"

# Premium Key Settings
DEFAULT_KEY_LENGTH = 16
MAX_KEY_DURATION_DAYS = 365

# Rate Limiting
COMMAND_COOLDOWN_SECONDS = 3
MASSBAN_DELAY_SECONDS = 0.5

# Colors for embeds
COLOR_SUCCESS = 0x00ff00
COLOR_ERROR = 0xff0000
COLOR_WARNING = 0xffaa00
COLOR_INFO = 0x0099ff
COLOR_PREMIUM = 0xffd700

# Bot Permissions Required
REQUIRED_PERMISSIONS = [
    "ban_members",
    "kick_members", 
    "manage_messages",
    "manage_roles",
    "manage_channels",
    "moderate_members"
]

# Anti-raid Settings
MAX_JOINS_PER_MINUTE = 5
RAID_ALERT_THRESHOLD = 10
AUTO_LOCKDOWN_THRESHOLD = 15
