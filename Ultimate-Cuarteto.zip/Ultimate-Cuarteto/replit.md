# Overview

This is an anti-raid Discord bot built with Python and discord.py that provides advanced moderation capabilities, premium user management, and automated raid protection for Discord servers. The bot features a comprehensive permission system with founder, admin, and premium user tiers, along with SQLite database storage for persistent data management.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Core Framework
- **Discord.py**: Primary framework for Discord API interaction with slash commands (app_commands)
- **Async/Await Pattern**: Fully asynchronous architecture using asyncio for concurrent operations
- **Cog-based Command Organization**: Commands are organized into logical groups (admin, moderation, antiraid, profile)

## Database Layer
- **SQLite with aiosqlite**: Lightweight, file-based database for persistent storage
- **Schema Design**: Four main tables for premium keys, premium users, bot admins, and user profiles
- **Connection Pooling**: Centralized database connection management through `get_db_connection()`

## Permission System
- **Three-tier Access Control**: Founder (hardcoded), Bot Admins (database-stored), Premium Users (key-based)
- **Premium Key System**: Time-limited or lifetime premium access through generated keys
- **Hierarchical Permissions**: Founder > Bot Admin > Premium User > Regular User

## Command Architecture
- **Slash Commands**: Modern Discord interaction system using app_commands
- **Permission Decorators**: Centralized permission checking through utility functions
- **Error Handling**: Comprehensive error handling with user-friendly messages

## Anti-Raid System
- **Rate Limiting**: Configurable thresholds for user joins per minute
- **Automatic Detection**: Real-time monitoring of suspicious activity patterns
- **Guild-specific Settings**: Per-server configuration for anti-raid parameters

## Utility Systems
- **Blacklist Manager**: Global user blacklist with caching for performance
- **Premium Manager**: Centralized premium status validation and management
- **Logging**: Structured logging to both file and console with different log levels

# External Dependencies

## Core Dependencies
- **discord.py**: Discord API wrapper for bot functionality
- **aiosqlite**: Asynchronous SQLite database interface
- **asyncio**: Built-in Python async framework

## Database
- **SQLite**: Local file-based database (`antiraid_bot.db`) for data persistence
- No external database server required

## Discord Integration
- **Discord API**: Full integration with Discord's slash command system
- **Required Bot Permissions**: ban_members, kick_members, manage_messages, manage_roles, manage_channels, moderate_members
- **Intents**: message_content, members, guilds, bans for comprehensive server monitoring

## Logging and Configuration
- **Python Logging**: Built-in logging module for application monitoring
- **File-based Configuration**: Configuration values stored in `config.py` for easy management